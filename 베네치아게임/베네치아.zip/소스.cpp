#include"Interface.h"
#include"Play.h"
void main()
{
	char buf[256];
	sprintf(buf, "mode con: cols=%d lines=%d", WIDTH * 2, HEIGHT+4);
	system(buf);
	Play p;
	p.StartMenu();
}