#include "Word.h"

void Word::DrawOrDelete(bool BlindWord,int start, int lenth,int Type)
{
	for (int i = start; i < lenth; i++)
	{
		gotoxy(m_ix + i, m_iy);
		if(!((m_ix +i >=44 && m_ix+i <=84) && (m_iy > 24 && m_iy < 30)))
		{
			if (Type == DELETE) cout << " ";
			else if (Type == DRAW)
			{
				if (BlindWord == true)
					cout << "=";
				else
					cout << m_strWord[i];
			}
			else cout << "�߸��� �����Դϴ�.";
		}
	}
}

bool Word::DrawWord(int y, bool BlindWord)
{

	if (m_iColor == 1) PUPPLE
	else BLUE_GREEN

	 if ((m_ix + m_strWord.length() >= 44 && m_ix <= 84) && (m_iy >= 24 && m_iy < 30))
	{
		int LeftWordCheck = 44 - m_ix;
		int RightWordCheck = (m_ix + m_strWord.length()) - 84;
			
		if (LeftWordCheck > 0)
		{
			if (m_iy == 24) LeftWordCheck = m_strWord.length(); // â ��
			DrawOrDelete(BlindWord,0, LeftWordCheck,DELETE);
			m_iy += y;
			LeftWordCheck = 44 - m_ix;
			if(m_iy == 30)  LeftWordCheck = m_strWord.length();
			DrawOrDelete(BlindWord,0, LeftWordCheck, DRAW);
		}
		else if (RightWordCheck > 0)
		{
			if (m_iy == 24) RightWordCheck = m_strWord.length();
			DrawOrDelete(BlindWord,m_strWord.length() - RightWordCheck, m_strWord.length(),DELETE);
			m_iy += y;
			RightWordCheck = (m_ix + m_strWord.length()) - 84;
			if (m_iy == 30)  RightWordCheck = m_strWord.length();
			DrawOrDelete(BlindWord,m_strWord.length() - RightWordCheck, m_strWord.length(),DRAW);
		}
		else
		{
			if (m_iy == 24) DrawOrDelete(BlindWord,0, m_strWord.length(), DELETE);
			m_iy += y;
			if (m_iy == 30) DrawOrDelete(BlindWord,0, m_strWord.length(), DRAW);
		}
	}
	else
	{
		DrawOrDelete(BlindWord,0, m_strWord.length(), DELETE);
		m_iy += y;
		if (m_iy < HEIGHT - 1)
		{
			DrawOrDelete(BlindWord,0, m_strWord.length(), DRAW);
		}
		else
			return true;
	}
	ORIGINAL
	return false;
}	