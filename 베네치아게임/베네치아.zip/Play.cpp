#include "Play.h"

/*
	���� �ؾ��Ұ� 
	�Լ��� �� �� ����
	�ܾ� �������°� �� �� ����Ҽ����� �Ұ�
*/

Play::Play() :m_iLife(GAMEBASEINFO_LIFEMAX), m_iScore(0), m_strPlayerName("? ? ?"), m_iLevel(1)
{}

void Play::Mapdraw(int Width, int Height, int StartX, int StartY)
{
	for (int y = 0; y < Height; y++)
	{
		gotoxy(StartX, StartY + y);
		for (int x = 0; x < Width; x++)
		{
			if (x == 0 && y == 0) cout << "��";
			else if (x == Width - 1 && y == Height - 1) cout << "��";
			else if (x == 0 && y == Height - 1) cout << "��";
			else if (x == Width - 1 && y == 0) cout << "��";
			else if (x == 0 || x == Width - 1) cout << "��";
			else if (y == 0 || y == Height - 1) cout << "��";
			else cout << "  ";
		}
	}
	PlayerInfo();
}
void Play::PlayerInfo()
{
	gotoxy(1, HEIGHT + 1);
	cout << "Life : ";
	for (int i = 0; i < m_iLife; i++)
	{
		cout << "��";
	}
	gotoxy(WIDTH - 5, HEIGHT + 1);
	cout << "���� : " << m_iScore;
	gotoxy(WIDTH + 45, HEIGHT + 1);
	cout << "Name : " << m_strPlayerName;
}

void Play::ChangeLifeOrScore(int Type)
{
	if (Type == GAMEBASEINFO_LIFE)
	{
		m_iLife -= 1;
		gotoxy(8+(m_iLife*2),HEIGHT+1);
		cout << "  ";
	}
	else
	{
		m_iScore += 100;
		gotoxy(WIDTH + 2, HEIGHT + 1);
		cout << m_iScore;
	}
}

void Play::PrintStory()
{
	ifstream StoryLoad;
	int CurClock;
	int OldClock = clock();
	string SaveStory[10], StoryTmp;
	int iHeight = HEIGHT * 0.1;
	system("cls");
	Mapdraw(WIDTH, HEIGHT, 0, 0);
	Mapdraw(20, 5, 44, 25);
	DrawMidText("Skip : s", WIDTH, iHeight + 24);
	StoryLoad.open("����ġ��_���丮.txt");
	if (StoryLoad.is_open())
	{
		int i = 0;
		while (!StoryLoad.eof())
		{
			CurClock = clock();

			if (CurClock - OldClock >= GAMESPEED_STORYSPEED)
			{
				getline(StoryLoad, SaveStory[i]);
				if (i >= 9)
				{
					for (int j = 0; j < 9; j++)
					{
						StoryTmp = SaveStory[j];
						SaveStory[j] = SaveStory[j + 1];
						SaveStory[j + 1] = StoryTmp;
						DrawMidText("                                       ", WIDTH, iHeight + 5 + j);
						DrawMidText(SaveStory[j], WIDTH, iHeight + 5 + j);
					}
				}
				else { DrawMidText(SaveStory[i], WIDTH, iHeight + 5 + i);  i++; }
				OldClock = CurClock;
			}
			if (kbhit())
			{
				char SkipKey = getch();
				if (SkipKey == 's')
					break;
			}
		}
		StoryLoad.close();
	}
}

bool Play::EndGame()
{
	ofstream SavePlayer;
	SavePlayer.open("Rank.txt", ios::app);
	if (SavePlayer.is_open())
	{
		SavePlayer << m_strPlayerName;
		SavePlayer << " ";
		SavePlayer << m_iLevel;
		SavePlayer << " ";
		SavePlayer << m_iScore;
	}
	m_strPlayerName = "? ? ?";
	m_iLife = GAMEBASEINFO_LIFEMAX;

	return false;
}

bool Play::InGame(int MaxWord)
{
	int iHeight = HEIGHT * 0.1;
	string strWord;
	int CreateClock = clock();
	int DropClock = clock();
	int CurClock;
	int DropSpeed = GAMESPEED_DROPSPEED;
	int CheckTime = 0;
	int FailTime = clock();
	bool BlindWord = false;
	bool FailWord = false;
	system("cls");
	Mapdraw(WIDTH, HEIGHT, 0, 0);
	Mapdraw(20, 5, 44, 25);
	gotoxy(65, iHeight + 24);
	while(1)
	{
		CurClock = clock();
		if (m_iLife == 0) return EndGame();

		//������ ������ ���ο� ������ ����
		if (m_iScore >= GAMEBASEINFO_NEEDSCORE)
		{
			WM.WordClear();
			m_iScore = 0;
			return true;
		}
	
		// �Է� ���н� ȿ��
		if (FailWord == true)
		{
			DrawMidText("Fail Word !!", WIDTH, iHeight + 24);
			if (CurClock - FailTime >= EFFECTTIME_FAILWORDTIMETRUM)
			{
				DrawMidText("                      ", WIDTH, iHeight + 24);
				FailTime = CurClock;

				strWord.clear();
				FailWord = false;
			}
		}
		else
		{
			FailTime = CurClock;
		}

		//�ܾ� ���� �ӵ�
		if(CurClock - CreateClock >= GAMESPEED_CREATETOWORDSPEED)
		{
			WM.CreateWord();
			CreateClock = CurClock;
		}

		//�ܾ� �������� �ӵ�
		if (CurClock - DropClock >= DropSpeed)
		{
			//ȿ�� �ߵ� �ð�
			if (DropSpeed != GAMESPEED_DROPSPEED)
			{
				CheckTime += GAMESPEED_DROPSPEED;
				if (CheckTime >= 2000)
				{
					CheckTime = 0;
					DropSpeed = GAMESPEED_DROPSPEED;
				}
			}
			if (BlindWord == true)
			{
				CheckTime += GAMESPEED_DROPSPEED;
				if (CheckTime >= 2500)
				{
					CheckTime = 0;
					BlindWord = false;
				}
			}
			m_iLife = WM.DropWord(m_iLife, BlindWord);
			DropClock = CurClock;
		}

			if (InputWord(GAMESTARTTYPE_INGAME, GAMEBASEINFO_MAXINPUT, strWord))
			{
				switch (WM.GetScore(strWord, m_iScore))
				{
				case EFFECT_FAST:
					DropSpeed = EFFECTTIME_FASTVALUE;
					break;
				case EFFECT_SLOW:
					DropSpeed = EFFECTTIME_SLOWVALUE;
					break;
				case EFFECT_STOP:
					DropSpeed = EFFECTTIME_STOPVALUE;
					break;
				case EFFECT_BLIND:
					BlindWord = true;
					break;
				case EFFECT_CLEAR:
					WM.WordClear();
					break;
				case EFFECT_FAILWORD:
					FailWord = true;
				default:
					break;
				};
				//
				strWord.clear();
			}
		//while ('\n' != getch()); // qjvj ����
	}
}

bool Play::InputWord(int Type, int MaxWord,string& InputChar)
{
	int iHeight = HEIGHT * 0.1;
	if (kbhit())
	{
		char ch = getch();
		if (ch == ENTER)
		{
			DrawMidText("                      ", WIDTH, iHeight + 24);
			return true;
		}
		else if (ch == BACKSPACE)
		{
			if (InputChar.size() == MaxWord)
				DrawMidText("                      ", WIDTH, iHeight + 21);
			if (InputChar.size() > 0)
				InputChar.erase(--InputChar.end());
			DrawMidText("                      ", WIDTH, iHeight + 24);
		}
		else
		{
			if(InputChar.size() < MaxWord) 
				InputChar.push_back(ch);
		}
		if (InputChar.size() == MaxWord) 
			DrawMidText(to_string(MaxWord) + "���� �ʰ�!!", WIDTH, iHeight + 21);

		DrawMidText(InputChar, WIDTH, iHeight + 24);
	}
	return false;
}

void Play::CreateName()
{
	int iHeight = HEIGHT * 0.1;
	string InputChar;
	system("cls");
	Mapdraw(WIDTH, HEIGHT, 0, 0);
	Mapdraw(20, 5, 44, 25);
	gotoxy(65, iHeight + 24);
	while(1)
	{
		if (InputWord(GAMESTARTTYPE_CREATENAME, GAMEBASEINFO_NAMEMAX, InputChar))
		{
			m_strPlayerName = InputChar;
			break;
		}
	}
}

void Play::GameStart()
{
	PrintStory();
	//���� �и��� ���� ����
	CreateName();
	int iHeight = HEIGHT * 0.1;
	WM.LoadWord();
	while(1)
	{
		system("cls");
		Mapdraw(WIDTH, HEIGHT, 0, 0);
		DrawMidText("�� " + to_string(m_iLevel) +"Stage ��", WIDTH, iHeight + 18);
		Sleep(1000);
		DrawMidText("             ", WIDTH, iHeight + 18);
		Mapdraw(20, 5, 44, 25);
		gotoxy(65, iHeight + 24);
		// ���ӽ�ŸƮ Ÿ�� ���� �� �и�
		if (InGame(20)) m_iLevel++;
		else break;
	}
	
}

void Play::StartMenu()
{
	int iHeight = HEIGHT * 0.1;
	while(1)
	{
		Mapdraw(WIDTH, HEIGHT, 0, 0);
		DrawMidText("�١� �� �� ġ �� �ڡ�", WIDTH, iHeight + 5);
		DrawMidText("1. Game Start", WIDTH, iHeight + 14);
		DrawMidText("2.Rank", WIDTH, iHeight + 17);
		DrawMidText("3.Exit", WIDTH, iHeight + 20);
		switch (MenuSelectCursor(3, 3, 20, iHeight + 14))
		{
		case 1:
			GameStart();
			break;
		case 2:
			PrintRank();
			break;
		case 3:
			return;
		}
	}

}

void Play::PrintRank()
{
	fstream LoadRank; // ���̵� ���� ����
	string LoadId;
	Rank* Ranker;
	int LoadLevel;
	int LoadScore;
	LoadRank.open("Rank.txt");
	if (LoadRank.is_open())
	{
		while (!LoadRank.eof())
		{
			LoadRank >> LoadId;
			LoadRank >> LoadLevel;
			LoadRank >> LoadScore;
			Ranker = new Rank(LoadId, LoadLevel, LoadScore);
			m_vRankList.push_back(Ranker);
		}
		LoadRank.close();
	}

	for (int i = 0; i < m_vRankList.size(); i++)
	{
		for (int j = i + 1; j < m_vRankList.size(); j++)
		{
			if ((m_vRankList[i]->GetLevel() < m_vRankList[j]->GetLevel()) ||
				(m_vRankList[i]->GetLevel() == m_vRankList[j]->GetLevel() &&
					m_vRankList[i]->GetScore() < m_vRankList[j]->GetScore()))
			{
				Ranker = new Rank;
				Ranker = m_vRankList[i];
				m_vRankList[i] = m_vRankList[j];
				m_vRankList[j] = Ranker;
			}
		}
	}

	Mapdraw(WIDTH, HEIGHT, 0, 0);
	Mapdraw(20, 5, 44, 2);
	DrawMidText("Ranking",WIDTH,4);
	gotoxy(2,8);
	for (int i = 0; i < WIDTH - 2; i++)
	{
		cout << "::";
	}
	gotoxy(40, 10);
	cout << "����\t" << "���̵�\t\t" << "���̵�\t\t" << "����";
	for (int i = 0; i < m_vRankList.size(); i++)
	{
		if (i == 10)
			break;
		gotoxy(40, 11 + i*2);
		cout << i + 1 << "��\t";
		m_vRankList[i]->Print();
	}
	getch();
}

Play::~Play(){}