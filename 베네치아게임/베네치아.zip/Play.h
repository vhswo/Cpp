#pragma once
#include"WordManager.h"
#include"Rank.h"

enum GAMESTARTTYPE
{
	GAMESTARTTYPE_CREATENAME = 1,
	GAMESTARTTYPE_INGAME
};
enum GAMEBASEINFO
{
	GAMEBASEINFO_LIFEMAX = 9,
	GAMEBASEINFO_LIFE = 1,
	GAMEBASEINFO_SCORE,
	GAMEBASEINFO_NEEDSCORE = 2000,
	GAMEBASEINFO_NAMEMAX =10,
	GAMEBASEINFO_MAXINPUT = 20
};
enum GAMESPEED
{
	GAMESPEED_STORYSPEED = 500,
	GAMESPEED_CREATETOWORDSPEED = 2000,
	GAMESPEED_DROPSPEED = 500
};
enum EFFECTTIME
{
	EFFECTTIME_FAILWORDTIMETRUM = 1500,
	EFFECTTIME_SLOWVALUE = 1000,
	EFFECTTIME_FASTVALUE = 250,
	EFFECTTIME_STOPVALUE = 2000
};

class Play
{
private:
	//vector<Word*> m_vWordCreate;
	vector<Rank*> m_vRankList;
	string m_strPlayerName;
	int m_iLife;
	int m_iScore;
	int m_iLevel;
	WordManager WM;
public:
	Play();
	~Play();
	void StartMenu();
private:

	void Mapdraw(int Width, int Height, int StartX, int StartY);
	void GameStart();
	void PrintStory();
	void CreateName();
	bool InputWord(int Type,int MaxWord, string& InputChar);
	bool InGame(int MaxWord);
	void PlayerInfo();
	void PrintRank();
	void ChangeLifeOrScore(int Type);
	bool EndGame();
	
};