#include "WordManager.h"

void WordManager::LoadWord()
{
	fstream LoadWord;
	string Words;
	LoadWord.open("Word.txt");
	if (LoadWord.is_open())
	{
		while (!LoadWord.eof())
		{
			getline(LoadWord,Words);
			WordTmp  = new Word(Words);
			m_vWordList.push_back(WordTmp);
		}
		LoadWord.close();
	}
}

void WordManager::CreateWord()
{
	srand((unsigned)time(NULL));
	int GabageValue = rand() % 10;
	int RandX = rand() % WIDTH * 1.8 + 2;
	int RandCreate = rand() % m_vWordList.size();
	int RandCreate2 = rand() % m_vWordList.size();
	int RandSpecial = rand() % 4+1;
	int Color;

	if (RandSpecial == 4) Color = 1;
	else Color = 2;

	WordTmp = new Word(m_vWordList[RandCreate2]->stringtmp(), RandX, 1, Color);
	m_vWordCreate.push_back(WordTmp);
}

int WordManager::DropWord(int life, bool BlindWord)
{
	for (int i = 0; i < m_vWordCreate.size(); i++)
	{
		if (m_vWordCreate[i]->DrawWord(1, BlindWord))
		{
			life -= 1;
			gotoxy(8 + (life * 2), HEIGHT + 1);
			cout << "  ";
			m_vWordCreate.erase(m_vWordCreate.begin());
			i--;
			if (life == 0)
				return life;
		}
	}	

	return life;
}

int WordManager::GetScore(string BringWord, int& score)
{
	int iEffect = 6;
	srand((unsigned)time(NULL));
	for (int i = 0; i < m_vWordCreate.size(); i++)
	{
		if (BringWord == m_vWordCreate[i]->stringtmp())
		{
			if (m_vWordCreate[i]->GetColor() == 1)
			{
				iEffect = (rand() % 4) + 1;
			}
			else
				iEffect = 7;
			string Wordsize = m_vWordCreate[i]->stringtmp();
			m_vWordCreate[i]->DrawOrDelete(false,0, Wordsize.length(), DELETE);
			m_vWordCreate.erase(m_vWordCreate.begin() + i);
			score += Wordsize.length() * 33;
			gotoxy(WIDTH + 2, HEIGHT + 1);
			cout << score;
		}
	}
	return iEffect;
}

void WordManager::WordClear()
{
	for (int i = 0; i < m_vWordCreate.size(); i++)
	{
		string Wordsize = m_vWordCreate[i]->stringtmp();
		m_vWordCreate[i]->DrawOrDelete(false,0, Wordsize.length(),DELETE);
		m_vWordCreate.erase(m_vWordCreate.begin() + i);
		i--;
	}
}
