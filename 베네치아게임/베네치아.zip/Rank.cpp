#include "Rank.h"
Rank ::Rank(string name, int level, int score)
{
	m_strID = name;
	m_iLevel = level;
	m_iScore = score;
}

void Rank::Print()
{
	cout << m_strID << "\t\t  " << m_iLevel << "\t\t" << m_iScore;
}