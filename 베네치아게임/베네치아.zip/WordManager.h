#pragma once
#include"Word.h"
class WordManager
{
private:
	vector<Word*> m_vWordList,m_vWordCreate;
	Word* WordTmp;
public:
	void LoadWord();
	void CreateWord();
	void WordClear();
	int DropWord(int life,bool BlindWord);
	int GetScore(string BringWord,int& score);
};

