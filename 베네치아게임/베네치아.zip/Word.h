#pragma once
#include"Interface.h"	
class Word
{
protected:
	int m_ix, m_iy;
	int m_iColor;
	string m_strWord;
public:
	Word(){}
	Word(string Word) { m_strWord = Word; }
	Word(string Word, int x, int y,int color)
	{
		m_strWord = Word; m_ix = x; m_iy = y; m_iColor = color;
		DrawWord(0,false);
	}
	string stringtmp() { return m_strWord; }
	int GetColor() { return m_iColor; }
	bool DrawWord(int y, bool BlindWord);
	void DrawOrDelete(bool BlindWord,int start,int lenth, int Type);
};

