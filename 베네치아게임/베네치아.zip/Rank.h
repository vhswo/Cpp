#pragma once
#include"Interface.h"	
class Rank
{
private:
	string m_strID;
	int m_iLevel;
	int m_iScore;
public:
	Rank(){}
	Rank(string name,int level,int score);
	void Print();
	int GetLevel() const { return m_iLevel; }
	int GetScore() const { return m_iScore; }
};

