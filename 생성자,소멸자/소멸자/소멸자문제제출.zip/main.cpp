#include"Filter.h"
void main()
{
	Filter AF;
	AF.Dlsp();
}