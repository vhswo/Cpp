#include "Filter.h"



Filter::Filter()
{
	while (1)
	{
		cout << "��ȭ��ȣ �Է� : ";
		cin >> m_strPhoneNumber;
		m_cNumber = new char[m_strPhoneNumber.length() + 3];
		strcpy(m_cNumber, m_strPhoneNumber.c_str());
		if (m_strPhoneNumber.length() == PHONENUMBERMAX && m_cNumber[1] == '1')
		{
			PhoneFilter();
			break;
		}
		else if (m_strPhoneNumber.length() == INTERNETPHONENUMBERMAX && (m_cNumber[1] > '2' && m_cNumber[1] <= '6'))
		{
			AreaFilter();
			break;
		}
		else if (m_strPhoneNumber.length() == SEOULINTERNETNUMBER && (m_cNumber[1] == '2'))
		{
			SeoulFilter();
			break;
		}
		else
			cout << "�߸� �Է��ϼ̽��ϴ�";
	};
}
Filter::~Filter()
{
	cout << m_cNumber << "�� ���� �Ҵ��� �����մϴ�.\n";
	delete[]m_cNumber;
}

void Filter::Dlsp()
{
	cout << "�ϼ��� ��ȣ : " << m_cNumber << endl;
}

void Filter::SeoulFilter()
{
	for (int i = 0, j = 0; i < SEOULINTERNETNUMBER + 3; i++)
	{

		if (i == HYPHENFIRSTSEOUL || i == HYPHENLASTSEOUL)
		{
			m_cNumber[i] = '-';
		}
		else
		{
			m_cNumber[i] = m_strPhoneNumber[j];
			j++;
		}
	}
}

void Filter::PhoneFilter()
{
	for (int i = 0, j = 0; i < PHONENUMBERMAX + 3; i++)
	{

		if (i == HYPHENFIRST || i == HYPHENPHONE)
		{
			m_cNumber[i] = '-';
		}
		else
		{
			m_cNumber[i] = m_strPhoneNumber[j];
			j++;
		}
	}
}

void Filter::AreaFilter()
{
	for (int i = 0, j = 0; i < INTERNETPHONENUMBERMAX + 3; i++)
	{

		if (i == HYPHENFIRST || i == HYPHENINTERNET)
		{
			m_cNumber[i] = '-';
		}
		else
		{
			m_cNumber[i] = m_strPhoneNumber[j];
			j++;
		}
	}
}