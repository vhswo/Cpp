#pragma once
#include<iostream>
#include<string>
#define SEOULINTERNETNUMBER 9
#define INTERNETPHONENUMBERMAX 10
#define PHONENUMBERMAX 11
#define HYPHENFIRSTSEOUL 2
#define HYPHENFIRST 3
#define HYPHENLASTSEOUL 6
#define HYPHENINTERNET 7
#define HYPHENPHONE 8
using namespace std;


class Filter
{
private:
	char* m_cNumber;
	string m_strPhoneNumber;
public:
	Filter();
	~Filter();
	void AreaFilter();
	void PhoneFilter();
	void Dlsp();
	void SeoulFilter();
};



