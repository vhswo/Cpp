#pragma once
#include<iostream>
#include"Skill.h"
#include<string>
#include<Windows.h>

enum COMPUTAMENU
{
	COMPUTAMENU_START,
	COMPUTAMENU_STATUS,
	COMPUTAMENU_SKILL,
	COMPUTAMENU_TURNOFF,
	COMPUTAMENU_END
};

class Status
{
private:
	string m_strProductName, m_Turn, m_GraphyCard, m_Memory,m_CPU;
public:
	Status();
	void StatusInfo();

};

