#include"Status.h"

void main()
{
	Status TurnOn;
}