#include "Skill.h"

Skill::Skill()
{
	while (1)
	{
		system("cls");
		int iInput;
		cout << "1.����" << endl;
		cout << "2.�޸���" << endl;
		cout << "3.�׸���" << endl;
		cout << "4.���ư���" << endl;
		cout << "���� >>>>>";
		cin >> iInput;
		switch ((SKILLMENU)iInput)
		{
		case SKILLMENU_CALCULATOR:
			system("calc");
			break;
		case SKILLMENU_MEMO:
			system("notepad");
			break;
		case SKILLMENU_DRAW:
			system("mspaint");
			break;
		case SKILLMENU_BACK:
			return;
		default:
			break;
		}

	}
}