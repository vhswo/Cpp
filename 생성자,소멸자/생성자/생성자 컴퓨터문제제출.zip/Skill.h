#pragma once
#include<iostream>
using namespace std;

enum SKILLMENU
{
	SKILLMENU_START,
	SKILLMENU_CALCULATOR,
	SKILLMENU_MEMO,
	SKILLMENU_DRAW,
	SKILLMENU_BACK,
	SKILLMENU_END
};

class Skill
{

public:
	Skill();

};

