#include "StudentManager.h"

StudentManager::StudentManager()
{
}

void StudentManager::AddStudent()
{
	Student st;
	st.SetStudent(m_StudentList.size()+1);
	m_StudentList.push_back(st);
}

void StudentManager::StudentList_Number()
{
	for (list<Student>::iterator iTer = m_StudentList.begin(); iTer != m_StudentList.end(); iTer++)
	{
		iTer->ShowStudent();
	}
}

list<Student>::iterator StudentManager::IntClassSearch(int iClass)
{
	for (list<Student>::iterator iTer = m_StudentList.begin(); iTer != m_StudentList.end(); iTer++)
	{
		if (iClass == iTer->GetClass())
			iTer->ShowStudent();
	}
	return m_StudentList.end();
}

void StudentManager::StudentList_Class()
{
	int i = 1;
	while(i <= 3)
	{
		cout << "==== " << i << "�г� ===== " << endl;
			IntClassSearch(i);
		cout << "====================" << endl << endl;
		i++;
	}
}

list<Student>::iterator StudentManager:: StrSearch(string strName)
{
	for (list<Student>::iterator iTer = m_StudentList.begin(); iTer != m_StudentList.end(); iTer++)
	{
		if (strName == iTer->GetName())
			return iTer;
	}
	return m_StudentList.end();
}


void StudentManager::Search_Name()
{
	string strName;
	cout << "ã�� �л��� �̸� : ";
	cin >> strName;
	
	list<Student>::iterator iTer = StrSearch(strName);
	if (iTer != m_StudentList.end())
		iTer->ShowStudent();
	else
		cout << "���� �л��Դϴ�.";
}

void StudentManager::Search_Class()
{
	int iNumber;
	cout << "ã�� �г� : ";
	cin >> iNumber;
	if (iNumber < 1 || iNumber >3)
		cout << "�߸��Է� �ϼ̽��ϴ�. (1~3)";
	else
		IntClassSearch(iNumber);

}

list<Student>::iterator StudentManager::IntNumberSearch(int iNumber)
{
	for (list<Student>::iterator iTer = m_StudentList.begin(); iTer != m_StudentList.end(); iTer++)
	{
		if (iNumber == iTer->GetNumber())
			return iTer;
	}
	return m_StudentList.end();
}

void StudentManager::DeleteLastOne()
{
	list<Student>::iterator iTer = IntNumberSearch(m_StudentList.size());
	if (iTer != m_StudentList.end())
	{
		m_StudentList.erase(iTer);
	}
	else
		cout << "�л��� �����ϴ�.";
}

void StudentManager::AllErase()
{
	m_StudentList.clear();
}


StudentManager::~StudentManager()
{
}