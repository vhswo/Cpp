#pragma once
#include<iostream>
#include<string>
using namespace std;

enum GENDER
{
	GENDER_MAN,
	GENDER_WOMAN
};

enum CLASS
{
	CLASS_1 =1,
	CLASS_2,
	CLASS_3
};

class Student
{
private:
	string m_strName;
	int m_iAge;
	int m_iNumber;
	CLASS m_eClass;
	GENDER m_eGender;

public:
	void SetStudent(int iCount);
	void ShowStudent();

	inline int GetNumber()
	{
		return m_iNumber;
	}
	inline string GetName()
	{
		return m_strName;
	}
	inline CLASS GetClass()
	{
		return m_eClass;
	}
	Student();
~Student();
};

