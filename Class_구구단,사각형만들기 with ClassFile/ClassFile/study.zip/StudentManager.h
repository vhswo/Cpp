#pragma once
#include"Student.h"
#include<list>
class StudentManager
{
private:
	list<Student> m_StudentList;
	
public:
	void AddStudent();
	void StudentList_Number();
	void StudentList_Class();
	list<Student>::iterator StrSearch(string strName);
	list<Student>::iterator IntClassSearch(int iNumber);
	list<Student>::iterator IntNumberSearch(int iNumber);
	void Search_Name();
	void Search_Class();
	void DeleteLastOne();
	void AllErase();
	inline int GetStudentCount()
	{
		return m_StudentList.size();
	}

	StudentManager();
	~StudentManager();
};

