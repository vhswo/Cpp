#include"StudentManager.h"
#include<Windows.h>
enum MAINMENU
{
	MAINMENU_START,
	MAINMENU_ADD,
	MAINMENU_STUDENTLIST_NUMBER,
	MAINMENU_STUDENTLIST_CLASS,
	MAINMENU_SEARCHNAME,
	MAINMENU_SEARCHCLASS,
	MAINMENU_DELETELASTONE,
	MAINMENU_ALLDELETE,
	MAINMENU_EXIT,
	MAINMENU_END
};

void main()
{
	int iInput;
	StudentManager SManager;
	while(1)
	{
		system("cls");
		cout << "====�л����� ���α׷�====" << endl;
		cout << "\t1.�л� ���" << endl;
		cout << "\t2.�л� ���<��ȣ��>" << endl;
		cout << "\t3.�л� ���<�г��>" << endl;
		cout << "\t4.�л� �˻�" << endl;
		cout << "\t5.�г� �˻�" << endl;
		cout << "\t6.������ �л� ����" << endl;
		cout << "\t7.�л� ��ü ����" << endl;
		cout << "\t8.����" << endl;
		cout << "\t(�л��� : " <<SManager.GetStudentCount() << ")" << endl;
		cout << "�Է� : ";
		cin >> iInput;
		
		switch (iInput)
		{
		case MAINMENU_ADD :
			SManager.AddStudent();
			break;
		case MAINMENU_STUDENTLIST_NUMBER :
			SManager.StudentList_Number();
			system("pause");
			break;
		case MAINMENU_STUDENTLIST_CLASS :
			SManager.StudentList_Class();
			system("pause");
			break;
		case MAINMENU_SEARCHNAME :
			SManager.Search_Name();
			system("pause");
			break;
		case MAINMENU_SEARCHCLASS :
			SManager.Search_Class();
			system("pause");
			break;
		case MAINMENU_DELETELASTONE :
			SManager.DeleteLastOne();
			system("pause");
			break;
		case MAINMENU_ALLDELETE :
			SManager.AllErase();
			break;
		case MAINMENU_EXIT :
			return;
		default:
			break;
		}
	}
}