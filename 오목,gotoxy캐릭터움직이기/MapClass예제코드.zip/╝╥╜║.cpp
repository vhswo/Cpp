#include"Mecro.h"
#include"MapDraw.h"
#include"Map.h"

void main()
{
	Map map;
	map.MapDraw();
}