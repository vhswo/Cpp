#include "OptionManager.h"
OptionManager::OptionManager() {
	m_iWidth = 20;
	m_iHeight = 20;
}
OptionManager::OptionManager(int* Width, int* Height){
	m_iWidth = (*Width);
	m_iHeight = (*Height);
}

int OptionManager::OutputMenu()
{
	int iInput;
	SubMap();
	TextLine("= Option =", m_iWidth, (m_iHeight / 10) * 2);
	TextLine("1.Map Size Set", m_iWidth, (m_iHeight / 10) * 3);
	TextLine("2.Cursor Custom", m_iWidth, (m_iHeight / 10) * 4);
	TextLine("3.Stone Custom", m_iWidth, (m_iHeight / 10) * 5);
	TextLine("4.Undo Count Set", m_iWidth, (m_iHeight / 10) * 6);
	TextLine("5.Return", m_iWidth, (m_iHeight / 10) * 7);
	TextLine("�Է� : ", m_iWidth, (m_iHeight / 10) * 8);
	cin >> iInput;
	return iInput;
}

void OptionManager::MapSize(int* Width, int* Height)
{
	while (1)
	{
		SubMap();
		TextLine("Width : ", (*Width), ((*Height) / 10) * 4);
		cin >> m_iWidth;
		TextLine("Height : ", (*Width), ((*Height) / 10) * 6);
		cin >> m_iHeight;
		if ((m_iWidth >= 20 && m_iWidth <= 90) && (m_iHeight >= 20 && m_iHeight <= 45))
		{
			(*Width) = m_iWidth;
			(*Height) = m_iHeight;
			break;
		}
		else
		{
			SubMap();
			TextLine("���� �Ұ���", (*Width), ((*Height) / 10) * 4);
			TextLine("(���� : 20 ~ 90, ���� : 20 ~ 45)", (*Width), ((*Height) / 10) * 6);
			system("pause");
		}
	}
	
}


void OptionManager::Custom(string* BlackCustom, string* WhiteCustom)
{
	SubMap();
	int iInput;
	TextLine("= Set Custom =", m_iWidth, (m_iHeight / 10) * 2);
	TextLine("1.��,��", m_iWidth, (m_iHeight / 10) * 3);
	TextLine("2.��,��", m_iWidth, (m_iHeight / 10) * 4);
	TextLine("3.��,��", m_iWidth, (m_iHeight / 10) * 5);
	TextLine("4.��,��", m_iWidth, (m_iHeight / 10) * 6);
	TextLine("5.Return", m_iWidth, (m_iHeight / 10) * 7);
	TextLine("�Է� : ", m_iWidth, (m_iHeight / 10) * 8);
	cin >> iInput;
	switch (iInput)
	{
	case CUSTOM_BASIC:
		(*BlackCustom) = "��";
		(*WhiteCustom) = "��";
		break;
	case CUSTOM_HEART:
		(*BlackCustom) = "��";
		(*WhiteCustom) = "��";
		break;
	case CUSTOM_POINTER:
		(*BlackCustom) = "��";
		(*WhiteCustom) = "��";
		break;
	case CUSTOM_NUMBER:
		(*BlackCustom) = "��";
		(*WhiteCustom) = "��";
		break;
	case CUSTOM_END:
		break;
	default:
		break;
	}
}

void OptionManager::UndoCount(int* Back)
{
	int iInput;
	int iBack;
	while(1)
	{
		SubMap();
		TextLine("= Set Undo =", m_iWidth, (m_iHeight / 10) * 3);
		TextLine("1.Set Undo Count", m_iWidth, (m_iHeight / 10) * 4);
		TextLine("2.Undo Off", m_iWidth, (m_iHeight / 10) * 5);
		TextLine("3.Return", m_iWidth, (m_iHeight / 10) * 6);
		TextLine("�Է� : ", m_iWidth, (m_iHeight / 10) * 7);
		cin >> iInput;
		switch (iInput)
		{
		case BACK_SETCOUNT:
			while (1)
			{
				SubMap();
				TextLine("������ Ƚ�� �Է�(�ִ� 10ȸ) : ", m_iWidth, (m_iHeight / 10) * 5);
				cin >> iBack;
				if (iBack < 0 || iBack > 10)
					TextLine("������ ���� �ʽ��ϴ�( 0 ~ 10) ", m_iWidth, (m_iHeight / 10) * 6);
				else
				{
					(*Back) = iBack;
					break;
				}
				system("pause");
			}
			break;
		case BACK_SETOFF:
			SubMap();
			TextLine("������ Off", m_iWidth, (m_iHeight / 10) * 5);
			(*Back) = 0;
			system("pause");
			break;
		case BACK_END:
			return;
		default:
			break;
		}
	}
}

void OptionManager::SubMap()
{
	system("cls");
	for (int y = 0; y < m_iHeight; y++)
	{
		if (y == 0)
		{
			cout << "��";
			for (int x = 1; x < m_iWidth - 1; x++)
				cout << "��";
			cout << "��";
		}
		else if (y == m_iHeight - 1)
		{
			cout << "��";
			for (int x = 1; x < m_iWidth - 1; x++)
				cout << "��";
			cout << "��";
		}
		else
		{
			cout << "��";
			for (int x = 1; x < m_iWidth - 1; x++)
				cout << "  ";
			cout << "��";
		}
		cout << endl;
	}
}

void OptionManager::TextLine(string str, int x, int y)
{
	if (x > str.size() / 2)
		x -= str.size() / 2;
	gotoxy(x, y);
	cout << str;
}

void OptionManager::gotoxy(int x, int y)
{
	COORD Pos = { x,y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}
OptionManager::~OptionManager() {}