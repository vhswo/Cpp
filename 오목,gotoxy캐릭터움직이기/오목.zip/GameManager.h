#pragma once
#include"PlayerManager.h"
#include"OptionManager.h"

enum MENU
{
	MENU_START,
	MENU_GAMESTART,
	MENU_CONTINUE,
	MENU_OPTION,
	MENU_REPLAY,
	MENU_EXIT
};

class GameManager
{
private:
	MENU m_eMenu; // �޴�
	PlayerManager m_cPlayerManager;
	OptionManager m_cOptionManager;
public:
	void Menu();
	GameManager();
	~GameManager();
};