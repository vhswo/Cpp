#pragma once
#include<iostream>
#include<Windows.h>
#include<string>
#include<conio.h>
#include<fstream>
#include <cstdio>
using namespace std;

#define PLAYERMAX 2
#define BLACK 0
#define WHITE 1
#define PLAYING 1
#define NONPLAYING 0
#define WIN 1