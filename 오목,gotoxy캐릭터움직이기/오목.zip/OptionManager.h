#pragma once
#include"Mecro.h"

enum CUSTOM
{
	CUSTOM_START,
	CUSTOM_BASIC,
	CUSTOM_HEART,
	CUSTOM_POINTER,
	CUSTOM_NUMBER,
	CUSTOM_END
};

enum BACK
{
	BACK_START,
	BACK_SETCOUNT,
	BACK_SETOFF,
	BACK_END
};

class OptionManager
{
private:
	int m_iWidth;
	int m_iHeight;
public:
	void MapSize(int* Width, int* Height);
	void UndoCount(int* iBack);
	void SubMap();
	void Custom(string* BlackCustom, string* WhiteCustom);
	int OutputMenu();
	void TextLine(string str, int x, int y);
	void gotoxy(int x, int y);
	OptionManager();
	OptionManager(int* Width, int* Height);
	~OptionManager();
};

