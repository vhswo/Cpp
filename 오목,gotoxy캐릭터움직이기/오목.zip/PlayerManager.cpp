#include "PlayerManager.h"
PlayerManager::PlayerManager() {
	m_strBlackCursor = "��";
	m_strWhiteCursor = "��";
	m_strBlackStone = "��";
	m_strWhiteStone = "��";
	m_iWidth = 20;
	m_iHeight = 20;
	m_iBack = 5;
	m_iWhiteBack = 5;
	m_iBlackBack = 5;
	OptionManager m_cOptionManager(&m_iWidth, &m_iHeight);

}

void PlayerManager::MapDraw()
{
	system("cls");
	for (int y = 0; y < m_iHeight; y++)
	{
		if (y == 0)
		{
			cout << "��";
			for (int x = 1; x < m_iWidth - 1; x++)
				cout << "��";
			cout << "��";
		}
		else if (y == m_iHeight - 1)
		{
			cout << "��";
			for (int x = 1; x < m_iWidth - 1; x++)
				cout << "��";
			cout << "��";
		}
		else
		{
			cout << "��";
			for (int x = 1; x < m_iWidth - 1; x++)
				cout << "��";
			cout << "��";
		}
		cout << endl;
	}
}
int PlayerManager::OutputMenu()
{
	int iInput;
	TextLine("�� �� �� ��", m_iWidth, (m_iHeight / 10) * 2);
	TextLine("1.���� ����", m_iWidth, (m_iHeight / 10) * 3);
	TextLine("2.�̾� �ϱ�", m_iWidth, (m_iHeight / 10) * 4);
	TextLine("3.�ɼ� ����", m_iWidth, (m_iHeight / 10) * 5);
	TextLine("4.�ٽ� ����", m_iWidth, (m_iHeight / 10) * 6);
	TextLine("5.���� ����", m_iWidth, (m_iHeight / 10) * 7);
	TextLine("����������������������", m_iWidth, (m_iHeight / 10) * 8);
	TextLine("��                  ��", m_iWidth, (m_iHeight / 10) * 8 + 1);
	TextLine("����������������������", m_iWidth, (m_iHeight / 10) * 8 + 2);
	gotoxy(m_iWidth, (m_iHeight / 10) * 8 + 1);
	cin >> iInput;
	return iInput;
}


void PlayerManager::Option(int Playing)
{
	while(1)
	{
		switch (m_cOptionManager.OutputMenu())
		{
		case OPTIONMENU_SETMAPSIZE :
			if(Playing == NONPLAYING)
				m_cOptionManager.MapSize(&m_iWidth, &m_iHeight);
			else
			{
				m_cOptionManager.SubMap();
				TextLine("���� �Ұ���", m_iWidth, (m_iHeight / 10) * 4);
				TextLine("(Game Play��)", m_iWidth, (m_iHeight / 10) * 5);
				system("pause");
			}
			break;
		case OPTIONMENU_SETCURSOR :
			m_cOptionManager.Custom(&m_strBlackCursor,&m_strWhiteCursor);
			break;
		case OPTIONMENU_SETSTONESKIN :
			m_cOptionManager.Custom(&m_strBlackStone, &m_strWhiteStone);
			break;
		case OPTIONMENU_SETBACKCOUNT :
			if (Playing == NONPLAYING)
				m_cOptionManager.UndoCount(&m_iBack);
			else
			{
				m_cOptionManager.SubMap();
				TextLine("���� �Ұ���", m_iWidth, (m_iHeight / 10) * 4);
				TextLine("(Game Play��)", m_iWidth, (m_iHeight / 10) * 5);
				system("pause");
			}
			break;
		case OPTIONMENU_EXIT :
			return;
		default:
			break;
		}
	}
}

void PlayerManager::KeyIndex(int BlackCount,int WhiteCount)
{
	TextLine("====����Ű====", m_iWidth, m_iHeight +1);
	TextLine("�̵� : a,s,w,d ������ : ENTER", m_iWidth, m_iHeight + 2);
	TextLine("������ : n �ɼ� : p ���� : esc", m_iWidth, m_iHeight + 3);
	TextLine("Player Name : ", m_iWidth/2, m_iHeight + 4);
	if (m_arrList.size() % 2 == 0)
		cout << m_strPlayer1Name;
	else
		cout << m_strPlayer2Name;
	cout << "\t������ : ";
	if (m_arrList.size() % 2 == 0)
		cout << BlackCount;
	else
		cout << WhiteCount;
	TextLine("Turn : ", m_iWidth, m_iHeight + 5);
	cout << m_arrList.size()+1;
}

void PlayerManager::InPlayer(Player pPlayer,int* BackCount, int* WinCount, int* Esc)
{
	Player tmp;
	int iturn = 0;  // iter�� ����� �̾Ƴ��� �𸣰��� �ӽ÷� ���� ����
	tmp = pPlayer.Move(m_arrList, WinCount, BackCount, Esc);

	if (tmp.GetOption() == PLAYING)
	{
		Option(PLAYING);
		MapDraw();
		for (list<Player>::iterator iter = m_arrList.begin(); iter != m_arrList.end(); iter++)
		{
			Pointer(*(iter->GetX()), *(iter->GetY()));
			if (iturn % 2 == 0)
				*(iter->GetStone()) = m_strBlackStone;
			else
				*(iter->GetStone()) = m_strWhiteStone;
			cout << *(iter->GetStone());
			iturn++;
			
		}
	}
	else if ((*tmp.GetBack()) == (*BackCount))
	{
		if((*Esc) == 0)
			m_arrList.push_back(tmp);
	}
	else
	{
		m_arrList.erase(--(m_arrList.end()));
		if(!m_arrList.empty())
		{
			MapDraw();
			KeyIndex(m_iBlackBack, m_iWhiteBack);
			for (list<Player>::iterator iter = m_arrList.begin(); iter != m_arrList.end(); iter++)
			{
				Pointer(*(iter->GetX()), *(iter->GetY()));
				cout << *(iter->GetStone());
			}
			--(*BackCount);
		}
	}
}

int PlayerManager::GetWinCount()
{
	return m_iWinCount;
}

void PlayerManager::Play(int New)
{
	ifstream LoadStone;
	ofstream SaveFinish,SaveContinue;
	Player tmp;
	m_iWinCount = 0;
	int Esc = 0;
	int xy = 0;	
	int count = 0;
	string stonee;
	string sizecheck;
	SaveContinue.open("SaveContinue.txt",ios::app);
	SaveContinue.close();
	LoadStone.open("SaveContinue.txt");
	if (LoadStone.is_open() && New ==2)
	{
		while (!LoadStone.eof())
		{
			if(count == 0)
			{
				LoadStone >> sizecheck;
				if (sizecheck == "" || sizecheck == "0")
				{
					cout << "�������� ������ �����ϴ�";
					return;
				}
			}
		
			if(count % 4 == 0)
			{
				LoadStone >> xy;
				*(tmp.GetX()) = xy;
			}
			else if(count % 4 == 1)
			{
				LoadStone >> xy;
				*(tmp.GetY()) = xy;
			}
			else if (count % 4 == 2)
			{
				LoadStone >> xy;
				*(tmp.GetBack()) = xy;
			}
			else
			{
				LoadStone >> stonee;
				*(tmp.GetStone()) = stonee;
				m_arrList.push_back(tmp);
			}
			count++;
		}
	}
	else
	{
		m_cOptionManager.SubMap();
		TextLine("P1 �̸�", m_iWidth, m_iHeight/3);
		TextLine("�Է� : ", m_iWidth, (m_iHeight / 3)+1);
		cin >> m_strPlayer1Name;
		TextLine("P2 �̸�", m_iWidth, m_iHeight / 2);
		TextLine("�Է� : ", m_iWidth, (m_iHeight / 2) + 1);
		cin >> m_strPlayer2Name;
		m_iBlackBack = 5;
		m_iWhiteBack = 5;
	}
	LoadStone.close();

	MapDraw();
	KeyIndex(m_iBlackBack, m_iWhiteBack); // ����Ű ���
	for (list<Player>::iterator iter = m_arrList.begin(); iter != m_arrList.end(); iter++)
	{
		Pointer(*(iter->GetX()), *(iter->GetY()));
		cout << *(iter->GetStone());
	}
	while (1)
	{
		m_cBlackPlayer = Player(m_strBlackStone, m_strBlackCursor, m_iWidth, m_iHeight);
		m_cWhitePlayer = Player(m_strWhiteStone, m_strWhiteCursor, m_iWidth, m_iHeight);
		
		if(m_arrList.size() %2 == 0)   //������� �� ����
			InPlayer(m_cBlackPlayer, &m_iBlackBack, &m_iWinCount,&Esc);
		else
			InPlayer(m_cWhitePlayer, &m_iWhiteBack, &m_iWinCount,&Esc);

		if (m_iWinCount == WIN)
		{
			cout << "���� �¸� !";
			SaveFinish.open("FinishGame.txt");
			if (SaveFinish.is_open())
			{
				for (list<Player>::iterator iter = m_arrList.begin(); iter != m_arrList.end(); iter++)
				{
					SaveFinish << " " << *(iter->GetX());
					SaveFinish << " " << *(iter->GetY());
					SaveFinish << " " << *(iter->GetStone());
				}
			}
			SaveFinish.close();
			SaveContinue.open("SaveContinue.txt");
			if (SaveContinue.is_open())
			{
				SaveContinue << "0";
			}
			SaveContinue.close();
			m_arrList.clear();
			system("pause");
			return;
		}
		if (Esc == 1)
		{
			SaveContinue.open("SaveContinue.txt");
			if (SaveContinue.is_open())
			{
				SaveContinue << "1";
				for (list<Player>::iterator iter = m_arrList.begin(); iter != m_arrList.end(); iter++)
				{
					SaveContinue << " " << *(iter->GetX());
					SaveContinue << " " << *(iter->GetY());
					SaveContinue << " " << *(iter->GetBack());
					SaveContinue << " " << *(iter->GetStone());
				}
			}
			SaveContinue.close();
			m_arrList.clear();
			return;
		}

	}
}

void PlayerManager::RePlay()
{
	Player tmp;
	ifstream LoadStone;
	int xy = 0;
	int count = 0;
	string stonee;
	LoadStone.open("FinishGame.txt");
		if (LoadStone.is_open())
		{
			while (!LoadStone.eof())
			{
				if (count % 3 == 0)
				{
					LoadStone >> xy;
					*(tmp.GetX()) = xy;
				}
				else if (count % 3 == 1)
				{
					LoadStone >> xy;
					*(tmp.GetY()) = xy;
				}
				else
				{
					LoadStone >> stonee;
					*(tmp.GetStone()) = stonee;
					m_arrList.push_back(tmp);
				}
				count++;
			}
			
			MapDraw();
			for (list<Player>::iterator iter = m_arrList.begin(); iter != m_arrList.end(); iter++)
			{
				Pointer(*(iter->GetX()), *(iter->GetY()));
				cout << *(iter->GetStone());
				Sleep(1000);
			}
			getch();
			m_arrList.clear();
	}
	else
	{
		m_cOptionManager.SubMap();
		TextLine("������ ������ ���ų� �������Դϴ�.", m_iWidth, m_iHeight / 3);
		getch();
	}
	LoadStone.close();
	
}

void PlayerManager::TextLine(string str, int x, int y)
{
	if (x > str.size() / 2)
		x -= str.size() / 2;
	gotoxy(x, y);
	cout << str;
}

void PlayerManager::Pointer(int x, int y)
{
	gotoxy(x * 2, y);
}

void PlayerManager::gotoxy(int x, int y)
{
	COORD Pos = { x,y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}


PlayerManager::~PlayerManager() {}