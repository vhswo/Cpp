#pragma once
#include"MapDraw.h"
class Player2
{
private:
	string m_strWhitePlayer = "��";
	int m_ix;
	int m_iy;
	int m_back = 5;
public:
	void Move();
	void Draw();
	void gotoxy(int x, int y);
	Player2(int x, int y);
	~Player2();


};

