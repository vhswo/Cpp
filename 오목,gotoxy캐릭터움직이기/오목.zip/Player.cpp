#include"Player.h"

Player::Player(string stone, string cursor,int x, int y)
{
	m_iWidth = x;
	m_iHeight = y;
	m_iback = 5;
	m_iwin = 0;
	m_iOption = 0;
	m_strPlayerStone = stone;
	m_iWinCount = 1;
	gotoxy(m_ix*2, m_iy);
	m_strCursor = cursor;
};
Player::Player() {}
Player Player::Move(list<Player> iList, int* WinCount,int* back,int* Esc)
{
	Player tmp;
	list<Player>::iterator iter;
	tmp.m_iback = (*back);

	m_ix = m_iWidth / 2;
	m_iy = m_iHeight / 2;

	if (!iList.empty())
	{
		for (list<Player>::iterator Location = (--iList.end()); Location != iList.begin(); Location--)
		{
			if (Location->m_strPlayerStone == m_strPlayerStone)
			{
				m_ix = *(Location->GetX());
				m_iy = *(Location->GetY());
				break;
			}
		}
	}
	while(1)
	{
		int WidthWin, LeftWidth, RightWidth;
		int HeightWin, UpHeight, DownHeight;
		int LeftWin, UpLeft, DownRight;
		int RightWin, UpRight, DownLeft;
		int LeftRightOtherStone, UpDownOtherStone;
		int FromUpLeftToDownRight, FromUpRightToLeftDown;

		Pointer(m_ix, m_iy);
		char cCh = getch();
		EraiserPointer(iList, m_ix, m_iy);
		gotoxy(m_ix * 2, m_iy);
		switch (cCh)
		{
		case SETKEY_UP :
			if(m_iy > 0)
				m_iy--;
			break;
		case SETKEY_DOWN:
			if(m_iy < m_iHeight-1)
				m_iy++;
			break;
		case SETKEY_LEFT:
			if (m_ix > 0)
				m_ix--;
			break;
		case SETKEY_RIGHT:
			if (m_ix < m_iWidth -1)
				m_ix++;
			break;
		case SETKEY_PUTSTONE:
			WidthWin = 0;
			LeftWidth = 1;
			RightWidth = 1;
			HeightWin = 0;
			UpHeight = 1;
			DownHeight = 1;
			LeftWin = 0;
			UpLeft = 1;
			DownRight = 1;
			RightWin = 0;
			UpRight = 1;
			DownLeft = 1;
			LeftRightOtherStone = 0;
			UpDownOtherStone = 0;
			FromUpLeftToDownRight = 0;
			FromUpRightToLeftDown = 0;
			tmp.m_ix = m_ix;
			tmp.m_iy = m_iy;
			tmp.m_strPlayerStone = m_strPlayerStone;
			for (iter = iList.begin(); iter != iList.end(); iter++)
			{
				if (iter->m_ix == tmp.m_ix && iter->m_iy == tmp.m_iy)
					break;
			}
			if (iter == iList.end())
			{
				for (int i = 1, j = 1; i <= 5 && j <= 5; i++, j++)
				{
					for (iter = iList.begin(); iter != iList.end(); iter++)
					{
						if (LeftWidth == i)
						{
							if (tmp.m_ix - i == iter->m_ix && iter->m_iy == tmp.m_iy && iter->m_strPlayerStone == tmp.m_strPlayerStone)
								LeftWidth++;
							if (tmp.m_ix - i == iter->m_ix && iter->m_iy == tmp.m_iy && iter->m_strPlayerStone != tmp.m_strPlayerStone)
								LeftRightOtherStone++;
						}
						if (RightWidth == i)
						{
							if (tmp.m_ix + i == iter->m_ix && iter->m_iy == tmp.m_iy && iter->m_strPlayerStone == tmp.m_strPlayerStone)
								RightWidth++;
							if (tmp.m_ix + i  == iter->m_ix && iter->m_iy == tmp.m_iy && iter->m_strPlayerStone != tmp.m_strPlayerStone)
								LeftRightOtherStone++;
						}
						if (UpHeight == i)
						{
							if (tmp.m_ix == iter->m_ix && tmp.m_iy - i == iter->m_iy && iter->m_strPlayerStone == tmp.m_strPlayerStone)
								UpHeight++;
							if (tmp.m_ix == iter->m_ix && tmp.m_iy - i == iter->m_iy && iter->m_strPlayerStone != tmp.m_strPlayerStone)
								UpDownOtherStone++;
						}
						if (DownHeight == i)
						{
							if (tmp.m_ix == iter->m_ix && tmp.m_iy + i == iter->m_iy && iter->m_strPlayerStone == tmp.m_strPlayerStone)
								DownHeight++;
							if (tmp.m_ix == iter->m_ix && tmp.m_iy + i == iter->m_iy && iter->m_strPlayerStone != tmp.m_strPlayerStone)
								UpDownOtherStone++;
						}
						if (UpLeft == i)
						{
							if (tmp.m_ix - i == iter->m_ix && tmp.m_iy - j == iter->m_iy && iter->m_strPlayerStone == tmp.m_strPlayerStone)
								UpLeft++;
							if (tmp.m_ix - i == iter->m_ix && tmp.m_iy - j == iter->m_iy && iter->m_strPlayerStone != tmp.m_strPlayerStone)
								FromUpLeftToDownRight++;

						}
						if (DownRight == i)
						{
							if (tmp.m_ix + i == iter->m_ix && tmp.m_iy + j == iter->m_iy && iter->m_strPlayerStone == tmp.m_strPlayerStone)
								DownRight++;
							if (tmp.m_ix + i == iter->m_ix && tmp.m_iy + j == iter->m_iy && iter->m_strPlayerStone != tmp.m_strPlayerStone)
								FromUpLeftToDownRight++;
						}
						if (UpRight == i)
						{
							if (tmp.m_ix + i == iter->m_ix && tmp.m_iy - j == iter->m_iy && iter->m_strPlayerStone == tmp.m_strPlayerStone)
								UpRight++;
							if (tmp.m_ix + i == iter->m_ix && tmp.m_iy - j == iter->m_iy && iter->m_strPlayerStone != tmp.m_strPlayerStone)
								FromUpRightToLeftDown++;
						}
						if (DownLeft == i)
						{
							if (tmp.m_ix - i == iter->m_ix && tmp.m_iy + j == iter->m_iy && iter->m_strPlayerStone == tmp.m_strPlayerStone)
								DownLeft++;
							if (tmp.m_ix - i == iter->m_ix && tmp.m_iy + j == iter->m_iy && iter->m_strPlayerStone != tmp.m_strPlayerStone)
								FromUpRightToLeftDown++;
						}
					}
				}
				WidthWin = LeftWidth + RightWidth - 1;
				HeightWin = UpHeight + DownHeight - 1;
				LeftWin = UpLeft + DownRight - 1;
				RightWin = UpRight + DownLeft - 1;
				if (WidthWin == 5 || HeightWin == 5 || LeftWin == 5 || RightWin == 5)
					(*WinCount)++;
				if ((WidthWin == 3 && HeightWin == 3 && LeftRightOtherStone + UpDownOtherStone == 0)
					|| (WidthWin == 3 && LeftWin == 3 && LeftRightOtherStone + FromUpLeftToDownRight == 0) 
					|| (WidthWin == 3 && RightWin == 3 && LeftRightOtherStone + FromUpRightToLeftDown == 0)
					|| (HeightWin == 3 && LeftWin == 3 && UpDownOtherStone + FromUpLeftToDownRight == 0)
					|| (HeightWin == 3 && RightWin == 3 && UpDownOtherStone + FromUpRightToLeftDown == 0)
					|| (LeftWin == 3 && RightWin == 3 && FromUpLeftToDownRight + FromUpRightToLeftDown == 0))
					break;
				cout << m_strPlayerStone;
				return tmp;
			}
			break;
		case SETKEY_BACK:
			if (tmp.m_iback > 0)
			{
				tmp.m_iback--;
				return tmp;
			}
			break;
		case SETKEY_OPTION:
			tmp.m_iOption = PLAYING;
			return tmp;
		case SETKEY_ESC:
			(*Esc)++;
			return tmp;
		default:
			break;
		}
	}
}
int Player::GetOption()
{
	return m_iOption;
}
int* Player:: GetX()
{
	return &m_ix;
}
int* Player::GetY()
{
	return &m_iy;
}
string* Player::GetStone()
{
	return &m_strPlayerStone;
}
int* Player::GetBack()
{
	return &m_iback;
}
void Player::Pointer(int x, int y)
{
	gotoxy(x * 2, y);
	cout << m_strCursor;
	gotoxy(-1, -1);
	return;

}
void Player::EraiserPointer(list<Player> iList,int x, int y)
{
	list<Player>::iterator iter;
	gotoxy(x * 2, y);
	for (iter = iList.begin(); iter != iList.end(); iter++)
	{
		if (iter->m_ix == x && iter->m_iy == y)
		{
			cout << iter->m_strPlayerStone;
			break;
		}
	}
	if (iter == iList.end())
	{
		if (y == 0 && x == 0)
			cout << "��";
		else if (y == 0 && x == m_iHeight - 1)
			cout << "��";
		else if (y == m_iHeight - 1 && x == 0)
			cout << "��";
		else if (y == m_iHeight - 1 && x == m_iWidth)
			cout << "��";
		else if (y == 0)
			cout << "��";
		else if (y == m_iHeight - 1)
			cout << "��";
		else if (x == 0)
			cout << "��";
		else if (x == m_iWidth - 1)
			cout << "��";
		else
			cout << "��";
	}
	gotoxy(-1, -1);
	return;
		
}



void Player::gotoxy(int x, int y)
{
	COORD Pos = { x,y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}

Player::~Player() {};