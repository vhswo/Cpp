#pragma once
#include"Mecro.h"
#include<list>
#include"OptionManager.h"

enum SETKEY
{
	SETKEY_START,
	SETKEY_UP = 'w',
	SETKEY_DOWN = 's',
	SETKEY_LEFT = 'a',
	SETKEY_RIGHT = 'd',
	SETKEY_OPTION = 'p',
	SETKEY_PUTSTONE = 13,
	SETKEY_BACK = 'n',
	SETKEY_ESC = 27,
	SETKEY_END
};

class Player
{
private:
	string m_strPlayerStone;
	int m_ix, m_iy;
	int m_iWidth,m_iHeight;
	int m_iback;
	int m_iwin;
	int m_iWinCount;
	int m_iOption;
	string m_strCursor;
	OptionManager m_cOption;
	public:
	Player Move(list<Player> iList, int *WinCount, int* back,int* Esc);
	int* GetX();
	int* GetY();
	int* GetBack();
	int GetOption();
	void EraiserPointer(list<Player> iList,int x, int y);
	string* GetStone();
	void Pointer(int x, int y);
	void gotoxy(int x, int y);
	Player(string Stone, string Cursor, int x, int y);
	Player();
	~Player();

};