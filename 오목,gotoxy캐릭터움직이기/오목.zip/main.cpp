#include"GameManager.h"


void main()
{
	GameManager cGM;
	cGM.Menu();
}

/*
	

*/