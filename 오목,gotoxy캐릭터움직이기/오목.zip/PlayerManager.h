#pragma once
#include"Player.h"
#include"Mecro.h"
#include"OptionManager.h"

enum OPTIONMENU
{
	OPTIONMENU_START,
	OPTIONMENU_SETMAPSIZE,
	OPTIONMENU_SETCURSOR,
	OPTIONMENU_SETSTONESKIN,
	OPTIONMENU_SETBACKCOUNT,
	OPTIONMENU_EXIT
};

class PlayerManager
{
private:
	Player m_cBlackPlayer;
	Player m_cWhitePlayer;
	list<Player> m_arrList;
	int m_iWinCount;
	int m_iBack;
	int m_iBlackBack;
	int m_iWhiteBack;
	int m_iWidth, m_iHeight;
	string m_strPlayer1Name, m_strPlayer2Name;
	string m_strBlackCursor, m_strWhiteCursor;
	string m_strBlackStone, m_strWhiteStone;
	OptionManager m_cOptionManager;
	enum OPTIONMENU m_eOptionMenu;
public:
	void Play(int New);
	void MapDraw();
	int OutputMenu();
	void KeyIndex(int BlackCount, int WhiteCount);
	void Option(int Ing);
	void InPlayer(Player pPlayer, int* BackCount,int* WinCount,int* Esc);
	void Pointer(int x, int y);
	void RePlay();
	void gotoxy(int x, int y);
	void TextLine(string str, int x, int y);
	int GetWinCount();
	PlayerManager();
	~PlayerManager();
};

