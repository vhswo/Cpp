#include "GameManager.h"


GameManager::GameManager() {}

void GameManager::Menu()
{
	while(1)
	{
		m_cPlayerManager.MapDraw(); //�� �׸���
		switch (int New = m_cPlayerManager.OutputMenu())
		{
		case MENU_GAMESTART:
		case MENU_CONTINUE:
			m_cPlayerManager.Play(New);
			break;
		case MENU_OPTION:
			m_cPlayerManager.Option(NONPLAYING);
			break;
		case MENU_REPLAY:
			m_cPlayerManager.RePlay();
			break;
		case MENU_EXIT:
			return;
		default:
			break;
		}
	}
}

GameManager::~GameManager() {}