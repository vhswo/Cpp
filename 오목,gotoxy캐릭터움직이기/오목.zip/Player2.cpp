#include "Player2.h"
Player2::Player2(int x, int y)
{
	m_ix = x;
	m_iy = y;
	gotoxy(m_ix * 2, m_iy);
	cout << m_strWhitePlayer;
};
void Player2::Move()
{
	gotoxy(m_ix * 2, m_iy);
	int iInput;
	cin >> iInput;
	switch (iInput)
	{
	case  'w':
		break;
	case 's':
		break;
	case 'a':
		break;
	case 'd':
		break;
	case 13:
		Draw();
		break;
	default:
		break;
	}
}

void Player2::Draw()
{
	gotoxy(m_ix, m_iy);
	cout << m_strWhitePlayer;
}

void Player2::gotoxy(int x, int y)
{
	COORD Pos = { x,y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}

Player2::~Player2() {};