#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include"CharacterDraw.h"
class Map
{
private:
	int m_ix;
	int m_iy;
	int m_iWidth;
	int m_iHeight;
	CharacterDraw CharacterDraw(int m_ix, int m_iy);
public:
	void MapDraw();
	void Move();
	Map();
	~Map();
};

