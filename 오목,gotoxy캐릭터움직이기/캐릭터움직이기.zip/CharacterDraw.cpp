#include"CharacterDraw.h"

void CharacterDraw::Eraser(int ix, int iy)
{
	gotoxy(ix, iy);
	cout << "  ";
	gotoxy(-1, -1);
	return;
}
void CharacterDraw::MoveDraw(int ix,int iy)
{
	gotoxy(ix,iy);
	cout << m_strCharacter;
	gotoxy(-1, -1);
	return;
}	
void CharacterDraw::Move(int Start_x, int Start_y, int Width, int Height)
{
	int m_iNowX = Start_x + Width;
	int m_iNowY = Start_y + Height / 2;
	while (1)
	{
		MoveDraw(m_iNowX, m_iNowY);
		char cMoveCheck = getch();
		Eraser(m_iNowX, m_iNowY);
		switch (cMoveCheck)
		{
		case 'w':
			if (m_iNowY > Start_x + 1)
				m_iNowY--;
			break;
		case 's':
			if (m_iNowY < Start_y + Height - 2)
				m_iNowY++;
			break;
		case 'a':
			if (m_iNowX > Start_x + 1)
				m_iNowX--;
			break;
		case 'd':
			if (m_iNowX < (Start_y + Width * 2) - 4)
				m_iNowX++;
			break;
		default:
			break;
		}
	}
}

CharacterDraw::CharacterDraw(int x, int y) {}
void CharacterDraw::gotoxy(int x, int y)
{
	COORD Pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}
CharacterDraw::~CharacterDraw() {}