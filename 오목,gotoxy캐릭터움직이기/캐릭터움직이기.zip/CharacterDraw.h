#pragma once
#include"Mecro.h"
class CharacterDraw
{
private:
	string m_strCharacter = "��";
	int m_iNowX;
	int m_iNowY;
public:
	CharacterDraw(int x,int y);
	void Move(int Start_x, int Start_y, int Width, int Height);
	void MoveDraw(int ix, int iy);
	void Eraser(int ix, int iy);
	void gotoxy(int x, int y);
	~CharacterDraw();
};