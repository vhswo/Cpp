#include "Character.h"
Character::Character(){}
void Character::SetCreate
(string strName, int Damage, int MaxHeath,
	int MaxExp, int GetExp, int Level, int Gold, int Exp, int CurHeath)
{
	m_strName = strName;
	m_iDamage = Damage, m_iMaxHeath = MaxHeath, m_iMaxExp = MaxExp;
	m_iGetExp = GetExp, m_iLevel = Level, m_iGold = Gold;
	m_iExp = Exp, m_iCurHeath = CurHeath;
}
void Character::Fight(int Damage) { m_iCurHeath -= Damage; }
void Character::UpExp(int GetExp){}
void Character::Reset() {}
void Character::Gold(int gold) { m_iGold += gold; }
string Character::GetName() { return m_strName; }
int Character::GetDamage(){	return m_iDamage;}
int Character::GetMaxHeath() { return m_iMaxHeath; }
int Character::GetExp() { return m_iGetExp; }
int Character::GetMaxExp() { return m_iMaxExp; }
int Character::GetLevel() { return m_iLevel; }
int Character::GetGold() { return m_iGold; }
int Character::GetNowExp() { return m_iExp; }
int Character::GetCurHeath() { return m_iCurHeath; }
string Character::GetWeaponType() { return m_cWeapon->WeaponType(); }
string Character::GetWeaponName() { return m_cWeapon->WeaponName(); }
int Character::GetWeaponDamage() { return m_cWeapon->Damage(); }
int Character::GetWeaponPrice() { return m_cWeapon->Price(); }
Character::~Character() {}
