#pragma once
#include"Mecro.h"
class Weapon
{
protected:
	string m_strType,m_strName;
	int m_iDamage, m_iPrice, m_iSell;
public:
	Weapon();
	void SetWeapon(string type, string name, int damage, int price)
	{
		m_strType = type;
		m_strName = name;
		m_iDamage = damage;
		m_iPrice = price;
	}
	string WeaponType() const { return m_strType; }
	string WeaponName() const { return m_strName; }
	int Damage() const { return m_iDamage; }
	int Price() const { return m_iPrice; }
	int Sell() const { return m_iSell; }
	virtual int Critical(int Damage) = 0;
	virtual ~Weapon();
};
class Dagger : public Weapon
{
public:
	int Critical(int Damage) 
	{
		srand((unsigned int)time(NULL));
		int iCriticalRand = rand() % 4;
		if (iCriticalRand == 1)
		{
			gotoxy(WIDTH-10, 14);
			cout << "ũ��Ƽ�� !! ������ : " << Damage * 5;
			Damage *= 10;
			getch();
		}
		return Damage;
	}
};

class Bow : public Weapon
{
public:
	int Critical(int Damage)
	{
		srand((unsigned int)time(NULL));
		int iCriticalRand = rand() % 9;
		if (iCriticalRand == 1)
		{
			gotoxy(WIDTH - 10, 14);
			cout << "ũ��Ƽ�� !! ������ : " << Damage * 10;
			Damage *= 10;
		}
		return Damage;
	}
};
class Hammer : public Weapon
{
public:
	int Critical(int Damage)
	{
		srand((unsigned int)time(NULL));
		int iCriticalRand = rand() % 1;
		if (iCriticalRand == 1)
		{
			gotoxy(WIDTH - 10, 14);
			cout << "ũ��Ƽ�� !! ������ : " << Damage * 1.2;
			Damage *= 1.2;
		}
		return Damage;
	}
};
class Gun : public Weapon
{
public:
	int Critical(int Damage)
	{
		srand((unsigned int)time(NULL));
		int iCriticalRand = rand() % 2;
		if (iCriticalRand == 1)
		{
			gotoxy(WIDTH - 10, 14);
			cout << "ũ��Ƽ�� !! ������ : " << Damage * 2;
			Damage *= 2;
		}
		return Damage;
	}
};
class Sword : public Weapon
{
public:
	int Critical(int Damage)
	{
		srand((unsigned int)time(NULL));
		int iCriticalRand = rand() % 9;
		if (iCriticalRand < 3)
		{
			gotoxy(WIDTH - 10, 14);
			cout << "ũ��Ƽ�� !! ������ : " << Damage * 1.5;
			Damage *= 4.5;
		}
		return Damage;
	}
};
class Wand : public Weapon
{
public:
	int Critical(int Damage)
	{
		srand((unsigned int)time(NULL));
		int iCriticalRand = rand() % 19;
		if (iCriticalRand == 1)
		{
			gotoxy(WIDTH - 10, 14);
			cout << "ũ��Ƽ�� !! ������ : " << Damage * 1000;
			Damage *= 1000;
		}
		return Damage;
	}
};
