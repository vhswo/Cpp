#pragma once
#include"Character.h"
#include"Mecro.h"
#include"Weapon.h"
#include<map>
#include<vector>

#define SAVEFILEMAX 11

enum WEAPONTYPE
{
	WEAPONTYPE_DAGGER =1,
	WEAPONTYPE_GUN,
	WEAPONTYPE_SWORD,
	WEAPONTYPE_WAND,
	WEAPONTYPE_BOW,
	WEAPONTYPE_HAMMER,
	WEAPONTYPE_EXIT
};

enum GAMEMENU
{
	GAMEMENU_DONGEON = 1,
	GAMEMENU_PLAYERINFO,
	GAMEMENU_MONSTERINFO,
	GAMEMENU_WEAPONSHOP,
	GAMEMENU_SAVE,
	GAMEMENU_EXIT
};
enum MONSTER
{
	MONSTER_GOBLIN,
	MONSTER_ORCHE,
	MONSTER_WEARWOLF,
	MONSTER_OUGER,
	MONSTER_SKELETONAHCHER,
	MONSTER_RICH,
	MONSTER_EXIT,
	MONSTER_END
};
enum MAINMENU
{
	MAINMENU_START = 1,
	MAINMENU_LOAD,
	MAINMENU_EXIT
};
class GameManager
{
private:
	vector<Character*> m_arrMonster;
	Character* Player1;
	map<string, vector<Weapon*>> m_weapons;
public:
	GameManager();
	string GetChoice(int result);
	string GetResult(int result);
	void Menu();
	bool FightDraw(int MonsterNumber);
	bool FightAction(string result, Character** Character1, Character* Character2);
	void GetExp(Character* Player, Character* Monster);
	bool DongeonMenu();
	void NewGame();
	void GameMenu();
	void PrintInfo(Character* Character, int Location);
	void LoadWeaponList();
	void OutputWeaponShop();
	void PrintWeapon(string weapontype,int i);
	void Save(int FileNumber);
	void Load(int LoadNumber);
	int SaveFileCheck();

	~GameManager();
};

