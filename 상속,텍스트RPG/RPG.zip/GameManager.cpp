#include "GameManager.h"
#include"Player.h"
#include"Monster.h"

GameManager::GameManager() {}

void GameManager::NewGame()
{
	ifstream BasicLoad;
	Character* tmp;
	string strtmp;
	int MonsterSize = 0, iDamage, iMaxHeath, MaxExp,
		iGetExp, iLevel, iGold, iExp = 0, iCurHeath;
	BasicLoad.open("DefaultMonster.txt");
	if (BasicLoad.is_open())
	{
		while (!BasicLoad.eof())
		{
			tmp = new Monster;
			if (MonsterSize == 0)
				BasicLoad >> MonsterSize;
			BasicLoad >> strtmp;
			BasicLoad >> iDamage;
			BasicLoad >> iMaxHeath;
			BasicLoad >> MaxExp;
			BasicLoad >> iGetExp;
			BasicLoad >> iLevel;
			BasicLoad >> iGold;
			iCurHeath = iMaxHeath;
			tmp->SetCreate(strtmp, iDamage, iMaxHeath, MaxExp, iGetExp, iLevel, iGold, iExp, iCurHeath);
			m_arrMonster.push_back(tmp);
		}
	}
	BasicLoad.close();
	MapDraw();
	DrawMidText("Player �̸� �Է� : ", WIDTH, HEIGHT * 0.5f);
	cin >> strtmp;
	BasicLoad.open("DefaultPlayer.txt");
	if (BasicLoad.is_open())
	{
		while (!BasicLoad.eof())
		{
			Player1 = new Player;
			BasicLoad >> iDamage;
			BasicLoad >> iMaxHeath;
			BasicLoad >> MaxExp;
			BasicLoad >> iGetExp;
			BasicLoad >> iLevel;
			BasicLoad >> iGold;
			iCurHeath = iMaxHeath;	
			Player1->SetCreate(strtmp, iDamage, iMaxHeath, MaxExp, iGetExp, iLevel, iGold, iExp, iCurHeath);
		}
	}
	BasicLoad.close();
}

void GameManager::PrintInfo(Character* Character,int Location)
{
	int iHeight = HEIGHT * 0.1f + Location;
	gotoxy(WIDTH - 10, iHeight);
	cout << "======" << Character->GetName() << "(" << Character->GetLevel() << "Lv)" << "======";
	gotoxy(WIDTH - 14, iHeight+1);
	cout << "���ݷ� : " << Character->GetDamage();
	gotoxy(WIDTH + 2, iHeight+1);
	cout << "ü�� : " << Character->GetCurHeath() <<"/"<< Character->GetMaxHeath();
	gotoxy(WIDTH - 14, iHeight+2);
	cout << "����ġ : " << Character->GetNowExp() <<"/" << Character->GetMaxExp();
	gotoxy(WIDTH + 2, iHeight+2);
	cout << "��°���ġ : " << Character->GetExp();
	gotoxy(WIDTH - 14, iHeight+3);
	cout << "��� : " << Character->GetGold();
	if (Character->WeaponCheck() == true)
	{
		gotoxy(WIDTH - 14, iHeight + 4);
		cout << "���� ���� ���� : " + Character->GetWeaponName();
	}
}

string GameManager::GetChoice(int result)
{
	if (result == 1)
		return "����";
	else if (result == 2)
		return "����";
	else
		return "��";
}

string GameManager::GetResult(int result)
{
	if (result == 0)
		return "Draw";
	else if (result == -1 || result == 2)
		return "WIN";
	else
		return "LOSE";
}

bool GameManager::FightAction(string result, Character** Character1,Character* Character2)
{
	if (result == "WIN")
	{
		int Damage = Character2->GetDamage();
		if (Character2->WeaponCheck() == true)
			Damage = Character2->WeaponDamage(Damage);
		(*Character1)->Fight(Damage);
		if ((*Character1)->GetCurHeath() <= 0)
			return false;
	}
	return true;
}

void GameManager::GetExp(Character* Characters, Character* Monster)
{
	Characters->UpExp(Monster->GetExp());
	Monster->Reset();
}

bool GameManager::FightDraw(int MonsterNumber)
{
	MapDraw();
	while(1)
	{
		if (kbhit())
		{
			MapDraw();
			char ch = getch();
			int result = ch - 48;
			int ComputerResult = rand() % 3 + 1;
			string str;

			str = GetChoice(ComputerResult);
			DrawMidText(str.c_str(), WIDTH, 18);
			str = GetResult(result - ComputerResult);
			DrawMidText(str, WIDTH, 17);
			if (FightAction(str, &Player1, m_arrMonster[MonsterNumber]) == false)
			{
				//ĳ���� ���
				MapDraw();
				DrawMidText("Player ���", WIDTH, 16);
				m_arrMonster.clear();
				getch();
				return false;
			}

			str = GetChoice(result);
			DrawMidText(str.c_str(), WIDTH, 12);
			str = GetResult(ComputerResult - result);
			DrawMidText(str, WIDTH, 13);
			if (FightAction(str, &m_arrMonster[MonsterNumber], Player1) == false)
			{	//���� ���
				MapDraw();
				DrawMidText(m_arrMonster[MonsterNumber]->GetName() + "���", WIDTH, 12);
				gotoxy(16, 14);
				cout << "Player ����ġ ȹ�� : " << m_arrMonster[MonsterNumber]->GetExp();
				getch();
				GetExp(&(*Player1), m_arrMonster[MonsterNumber]);
				break;
			}

		}
		PrintInfo(Player1,0);
		DrawMidText("���� : 1  ���� : 2  �� : 3 ", WIDTH, 10);
		gotoxy(2, HEIGHT * 0.5f);
		for (int x = 0; x < WIDTH*2 - 5; x++)
		{
			if (x == WIDTH - 3)
				cout << " ";
			else if (x == WIDTH - 2)
				cout << "vs";
			else if (x == WIDTH - 1)
				cout << " ";
			else
				cout << "-";
		}
		PrintInfo(m_arrMonster[MonsterNumber], 20);
		
	}
	return true;
}

bool GameManager::DongeonMenu()
{
	int iHeight = HEIGHT * 0.2f;
	MapDraw();
	DrawMidText("=====���� �Ա�=====", WIDTH, iHeight);
	DrawMidText("1������ : [������]", WIDTH, iHeight +6);
	DrawMidText("2������ : [��ũ]", WIDTH, iHeight + 8);
	DrawMidText("3������ : [�����ΰ�]", WIDTH, iHeight + 10);
	DrawMidText("4������ : [�����]", WIDTH, iHeight + 12);
	DrawMidText("5������ : [���̷����ó]", WIDTH, iHeight + 14);
	DrawMidText("6������ : [��ġ]", WIDTH, iHeight + 16);
	DrawMidText("���ư���", WIDTH, iHeight + 18);
	switch (MenuSelectCursor(MONSTER_END, 2, WIDTH - 24, iHeight + 6)-1)
	{
	case MONSTER_GOBLIN:
		return FightDraw(MONSTER_GOBLIN);
	case MONSTER_ORCHE:
		return FightDraw(MONSTER_ORCHE);
	case MONSTER_WEARWOLF:
		return FightDraw(MONSTER_WEARWOLF);
	case MONSTER_OUGER:
		return FightDraw(MONSTER_OUGER);
	case MONSTER_SKELETONAHCHER:
		return FightDraw(MONSTER_SKELETONAHCHER);
	case MONSTER_RICH:
		return FightDraw(MONSTER_RICH);
	case MONSTER_EXIT:
		return true;
	}
}

void GameManager::OutputWeaponShop()
{
	int iHeight = HEIGHT * 0.3f;
	string WeaponType;
	while(1)
	{
		MapDraw();
		DrawMidText("�١� Shop �ڡ�", WIDTH, iHeight);
		DrawMidText("Dagger", WIDTH, iHeight+2);
		DrawMidText("Gun", WIDTH, iHeight+4);
		DrawMidText("Sword", WIDTH, iHeight+6);
		DrawMidText("Wand", WIDTH, iHeight+8);
		DrawMidText("Bow", WIDTH, iHeight+10);
		DrawMidText("Hammer", WIDTH, iHeight+12);
		DrawMidText("���ư���", WIDTH, iHeight + 14);
		switch (MenuSelectCursor(WEAPONTYPE_EXIT, 2, WIDTH * 0.5f - 5, iHeight + 2))
		{
		case WEAPONTYPE_DAGGER:
			WeaponType = "Dagger";
			break;
		case WEAPONTYPE_GUN:
			WeaponType = "Gun";
			break;
		case WEAPONTYPE_SWORD:
			WeaponType = "Sword";
			break;
		case WEAPONTYPE_WAND:
			WeaponType = "Wand";
			break;
		case WEAPONTYPE_BOW:
			WeaponType = "Bow";
			break;
		case WEAPONTYPE_HAMMER:
			WeaponType = "Hammer";
			break;
		case WEAPONTYPE_EXIT:
			return;
		}
		PrintWeapon(WeaponType,0);
	}
}

void GameManager::GameMenu()
{
	int iHeight = HEIGHT * 0.3f;
	bool iRun = true;
	while (iRun)
	{
		MapDraw();
		DrawMidText("�١� DonGeon RPG �١�", WIDTH, iHeight);
		DrawMidText("Dongeon", WIDTH, iHeight + 2);
		DrawMidText("Player Info", WIDTH, iHeight + 4);
		DrawMidText("Monster Info", WIDTH, iHeight + 6);
		DrawMidText("Weapon Shop", WIDTH, iHeight + 8);
		DrawMidText("Save", WIDTH, iHeight + 10);
		DrawMidText("Exit", WIDTH, iHeight + 12);
		switch (MenuSelectCursor(GAMEMENU_EXIT, 2, WIDTH * 0.5f - 5, iHeight + 2))
		{
		case GAMEMENU_DONGEON:
			iRun = DongeonMenu();
			break;
		case GAMEMENU_PLAYERINFO:
			MapDraw();
			PrintInfo(Player1,10);
			getch();
			break;
		case GAMEMENU_MONSTERINFO:
			MapDraw();
			for (int i = 0; i < m_arrMonster.size(); i++)
			{
				PrintInfo(m_arrMonster[i], i*4);
			}
			getch();
			break;
		case GAMEMENU_WEAPONSHOP:
			OutputWeaponShop();
			break;
		case GAMEMENU_SAVE:
			Save(SaveFileCheck());
			break;
		case GAMEMENU_EXIT:
			return;
		}
	}
}

void GameManager::Save(int FileNumber)
{
	if (FileNumber == SAVEFILEMAX)
		return;
	
	ofstream SaveFile;
	SaveFile.open("SaveMonster" + to_string(FileNumber) + ".txt");
	if (SaveFile.is_open())
	{
		SaveFile << m_arrMonster.size() << endl;
		
		for (int i = 0; i < m_arrMonster.size(); i++)
		{
			SaveFile << m_arrMonster[i]->GetName() << " ";
			SaveFile << m_arrMonster[i]->GetDamage() << " ";
			SaveFile << m_arrMonster[i]->GetMaxHeath() << " ";
			SaveFile << m_arrMonster[i]->GetMaxExp() << " ";
			SaveFile << m_arrMonster[i]->GetExp() << " ";
			SaveFile << m_arrMonster[i]->GetLevel() << " ";
			SaveFile << m_arrMonster[i]->GetGold() << " ";
			SaveFile << m_arrMonster[i]->GetNowExp() << " ";
			SaveFile << m_arrMonster[i]->GetCurHeath() << endl;
		}
		SaveFile.close();
	}
	SaveFile.open("SavePlayer"+to_string(FileNumber)+".txt");
	if (SaveFile.is_open())
	{
		SaveFile << Player1->GetName() << " ";
		SaveFile << Player1->GetDamage() << " ";
		SaveFile << Player1->GetMaxHeath() << " ";
		SaveFile << Player1->GetMaxExp() << " ";
		SaveFile << Player1->GetExp() << " ";
		SaveFile << Player1->GetLevel() << " ";
		SaveFile << Player1->GetGold() << " ";
		SaveFile << Player1->GetNowExp() << " ";
		SaveFile << Player1->GetCurHeath();
		if (Player1->WeaponCheck() == true)
		{
			SaveFile << endl << 1 <<" ";
			SaveFile <<  Player1->GetWeaponType() << " ";
			SaveFile << Player1->GetWeaponName() << " ";
			SaveFile << Player1->GetWeaponDamage() << " ";
			SaveFile << Player1->GetWeaponPrice();
		}
		else
			SaveFile << endl << 0;
		SaveFile.close();
	}
}

void GameManager::PrintWeapon(string weapontype,int Size)
{
	while (1)
	{
		MapDraw();
		int iAutoHeight = 0,i = Size * 5,SizeMax = 5+i;
		int iHeight = HEIGHT * 0.2f;
		vector<Weapon*> weaponList = m_weapons[weapontype];
		int MaxSize = weaponList.size() / 5;
		gotoxy(WIDTH-10, iHeight - 4);
		cout << "���� Gold : " << Player1->GetGold();
		gotoxy(WIDTH - 6, iHeight - 2);
		cout << weapontype+" Shop";
		for (i;i < SizeMax; i++, iAutoHeight += 3)
		{
			if (i == weaponList.size())
				break;
			YELLOW
			gotoxy(WIDTH - 14, iHeight + iAutoHeight);
			cout << "���� : " << weaponList[i]->Price() << " ���� Ÿ�� : " << weaponList[i]->WeaponType();
			gotoxy(WIDTH - 16, iHeight + iAutoHeight + 1);
			cout << "�����̸� : " << weaponList[i]->WeaponName() << " ���ݷ� : " << weaponList[i]->Damage();
		}
		ORIGINAL
		gotoxy(WIDTH - 6, iHeight + iAutoHeight);
		cout << "����������";
		gotoxy(WIDTH - 6, iHeight + iAutoHeight+3);
		cout << "����������";
		gotoxy(WIDTH - 4, iHeight + iAutoHeight + 6);
		cout << "������";
		int CursorSize = i % 5;
		if(i % 5 == 0)
			CursorSize = 5;
		int iNext = CursorSize +1, iRetrun = CursorSize+2,iExit = CursorSize +3, k;
		k = MenuSelectCursor(CursorSize + 3, 3, 4, iHeight);		
		if (iNext == k && Size > 0)
			return PrintWeapon(weapontype, --Size);
		else if (iRetrun == k && MaxSize - Size > 0)
			return PrintWeapon(weapontype, ++Size);
		else if (iExit == k)
			return;
		else if(k <=5 && CursorSize >= k)
		{
			Player1->Gold(-weaponList[SizeMax + k - 6]->Price());
			Player1->EquipWeapon(weaponList[SizeMax + k - 6]);
		}
		else
			break;
		
	}
}

void GameManager::LoadWeaponList()
{
	ifstream Weapons;
	Weapon* cWeapon;
	string strType,strWeaponName;
	int iDamage, iPrice;
	Weapons.open("WeaponList.txt");
	while (!Weapons.eof())
	{
		Weapons >> strType;
		Weapons >> strWeaponName;
		Weapons >> iDamage;
		Weapons >> iPrice;

		if (strType == "Dagger")
		{
			cWeapon = new Dagger;
		}
		else if(strType == "Bow")
		{
			cWeapon = new Bow;
		}
		else if (strType == "Hammer")
		{
			cWeapon = new Hammer;
		}
		else if (strType == "Gun")
		{
			cWeapon = new Gun;
		}
		else if (strType == "Sword")
		{
			cWeapon = new Sword;
		}
		else
			cWeapon = new Wand;
		cWeapon->SetWeapon(strType, strWeaponName, iDamage, iPrice);
		m_weapons[strType].push_back(cWeapon);
	}		
	Weapons.close();
}

int GameManager::SaveFileCheck()
{
	int iHeight = HEIGHT * 0.1;
	string LoadFileCheck;
	ifstream GameLoad;
	MapDraw();
	for (int i = 1; i <= SAVEFILEMAX; i++)
	{
		gotoxy(16, iHeight + (i * 2));
		if (i == SAVEFILEMAX)
			cout << SAVEFILEMAX <<". ���ư���";
		else
		{
			GameLoad.open("SaveMonster" + to_string(i) + ".txt");
			if (GameLoad.is_open())
			{
				LoadFileCheck = "��";
				GameLoad.close();
			}
			else
				LoadFileCheck = "X";
			cout << i << "�� ���� : (���Ͽ��� : " << LoadFileCheck << ")";
		}
	}
	int k = MenuSelectCursor(SAVEFILEMAX, 2, 4, iHeight + 2);
	return k;
}

void GameManager::Load(int LoadNumber)
{
	if (LoadNumber == SAVEFILEMAX)
		return;
	ifstream LoadFile;
	Character* LoadMonster;
	string strName, WeaponType, WeaponName;
	int Damage, MaxHeath, MaxExp, GetExp, Level,
		Gold, Exp, CurHeath, MonsterSize = 0,
		WeaponCheck, WeaponDamage, WeaponPrice;
	LoadFile.open("SaveMonster"+to_string(LoadNumber)+".txt");
	if (LoadFile.is_open())
	{
		while(!LoadFile.eof())
		{
			LoadMonster = new Monster;
			if( MonsterSize ==0)
				LoadFile >> MonsterSize;
			LoadFile >> strName;
			LoadFile >> Damage;
			LoadFile >> MaxHeath;
			LoadFile >> MaxExp;
			LoadFile >> GetExp;
			LoadFile >> Level;
			LoadFile >> Gold;
			LoadFile >> Exp;
			LoadFile >> CurHeath;
			LoadMonster->SetCreate(strName,Damage,MaxHeath,MaxExp,GetExp,Level,Gold,Exp,CurHeath);
			m_arrMonster.push_back(LoadMonster);
		}
	}
	LoadFile.close();
	LoadFile.open("SavePlayer"+to_string(LoadNumber)+".txt");
	if (LoadFile.is_open())
	{
		while (!LoadFile.eof())
		{
			Player1 = new Player;
			LoadFile >> strName;
			LoadFile >> Damage;
			LoadFile >> MaxHeath;
			LoadFile >> MaxExp;
			LoadFile >> GetExp;
			LoadFile >> Level;
			LoadFile >> Gold;
			LoadFile >> Exp;
			LoadFile >> CurHeath;
			Player1->SetCreate(strName, Damage, MaxHeath, MaxExp, GetExp, Level, Gold, Exp, CurHeath);
			LoadFile >> WeaponCheck;
			if (WeaponCheck != 0)
			{	
				LoadFile >> WeaponType;
				LoadFile >> WeaponName;
				LoadFile >> WeaponDamage;
				LoadFile >> WeaponPrice;
				vector<Weapon*> weaponList = m_weapons[WeaponType];
				for (int i = 0; i < weaponList.size(); i++)
				{
					if (weaponList[i]->WeaponName() == WeaponName)
					{
						Player1->EquipWeapon(weaponList[i]);
						break;
					}
				}
			}
		}
		LoadFile.close();
	}
}

void GameManager::Menu()
{
	int iHeight = HEIGHT * 0.4f;
	LoadWeaponList();
	while (1)
	{
		MapDraw();
		DrawMidText("�١� DonGeon RPG �١�", WIDTH, iHeight);
		DrawMidText("New Game", WIDTH, iHeight + 2);
		DrawMidText("Load Game", WIDTH, iHeight + 4);
		DrawMidText("Game Exit", WIDTH, iHeight + 6);
		switch (MenuSelectCursor(MAINMENU_EXIT, 2, WIDTH * 0.5f - 5, iHeight + 2))
		{
		case MAINMENU_START:
			NewGame();
			break;
		case MAINMENU_LOAD:
			Load(SaveFileCheck());
			break;
		case MAINMENU_EXIT:
			return;
		}
		GameMenu();
	}
}
GameManager::~GameManager() {}