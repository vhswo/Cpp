#include"GameManager.h"

void main()
{
	char buf[256];
	sprintf(buf,"mode con: cols=%d lines=%d", WIDTH*2, HEIGHT + 1);
	system(buf);
	GameManager Gm;
	Gm.Menu();
}