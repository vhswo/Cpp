#include "Monster.h"
Monster::Monster() {}
void Monster::Reset() { m_iCurHeath = m_iMaxHeath; }
void Monster::EquipWeapon(Weapon* Weapon) { m_cWeapon = Weapon; }

bool Monster::WeaponCheck() { return false; }
int Monster::WeaponDamage(int Damage) { return Damage; }
Monster::~Monster() {}