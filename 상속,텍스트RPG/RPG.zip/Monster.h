#pragma once
#include"Character.h"
class Monster : public Character
{
public:
	Monster();
	void Reset();
	bool WeaponCheck();
	int WeaponDamage(int Damage);
	void EquipWeapon(Weapon* Weapon);
	~Monster();
};

