#pragma once
#include"Mecro.h"
#include"Weapon.h"
class Character
{
protected:
	Weapon* m_cWeapon = NULL;
	string m_strName;
	int m_iDamage, m_iMaxHeath, m_iMaxExp;
	int m_iGetExp, m_iLevel, m_iGold,m_iExp,m_iCurHeath;
public:
	Character();
	virtual void UpExp(int GetExp);
	virtual void SetCreate(string m_strName, int m_iDamage, int m_iMaxHeath,
		int m_MaxExp, int m_iGetExp, int m_iLevel, int m_iGold,int Exp, int CurHeath);
	virtual string GetName();
	virtual int GetDamage();
	virtual int GetMaxHeath();
	virtual int GetMaxExp();
	virtual int GetExp();
	virtual int GetLevel();
	virtual int GetGold();
	virtual int GetNowExp();
	virtual int GetCurHeath();
	virtual void Fight(int Damage);
	virtual void Gold(int gold);
	virtual void Reset();
	virtual string GetWeaponType();
	virtual string GetWeaponName();
	virtual int GetWeaponDamage();
	virtual int GetWeaponPrice();
	virtual bool WeaponCheck() = 0;
	virtual int WeaponDamage(int Damage) = 0;
	virtual void EquipWeapon(Weapon* Weapon) = 0;
	virtual ~Character();
};

