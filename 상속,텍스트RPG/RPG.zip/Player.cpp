#include "Player.h"
Player::Player() {}
void Player::Gold(int gold) { m_iGold += gold; }
void Player::EquipWeapon(Weapon* Weapon) { m_cWeapon = Weapon; }
void Player::UpExp(int GetExp)
{
	m_iExp += GetExp;
	while (m_iExp >= m_iMaxExp)
	{
		MapDraw();
		m_iExp -= m_iMaxExp;
		gotoxy(WIDTH, 12);
		cout << m_strName << "������ !!";
		int Num = (rand() % 5) + 1;
		m_iDamage += Num;
		gotoxy(WIDTH, 14);
		cout << "���ݷ� ���� : " << Num;
		Num = (rand() % 5) + 1;
		m_iMaxHeath += Num;
		gotoxy(WIDTH, 16);
		cout << "������ ���� : " << Num;
		m_iMaxExp += m_iMaxExp * 0.3;
		m_iCurHeath = m_iMaxHeath;
		m_iLevel++;
		getch();
	}
}

bool Player::WeaponCheck()
{
	if (m_cWeapon != NULL)
		return true;
	else
		return false;
}

int Player::WeaponDamage(int Damage)
{
	int iDamage;
	if (m_cWeapon != NULL)
	{
		iDamage = m_cWeapon->Critical(Damage + m_cWeapon->Damage());
		return iDamage;
	}
	else
		return Damage;
}
Player::~Player() {}