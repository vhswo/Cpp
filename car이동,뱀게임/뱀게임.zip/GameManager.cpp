#include "GameManager.h"

GameManager::GameManager() : 
	FeedMax(10),
	m_iWitdh(50), m_iHeight(25),
	m_iFeed(0)
	//m_iSneakX(m_iWitdh/2),m_iSneakY(m_iHeight/2),
	//m_eKeyValue(KEYVALUE_NONE)
{
}

void GameManager::Map()
{
	for (int y = 0; y < m_iHeight; y++)
	{
		for (int x = 0; x < m_iWitdh; x++)
		{
			if (y == 0)
				cout << "��";
			else if (x == 0)
				cout << "��";
			else if (y == m_iHeight - 1)
				cout << "��";
			else if (x == m_iWitdh - 1)
				cout << "��";
			else
				cout << "  ";
		}
		cout << endl;
	}
}

void GameManager::CreateWall()
{
	int RandomCreateWall;
	int WallMax;
	for(int y = 1; y < m_iHeight - 1; y++)
	{
		WallMax = 0;
		for (int x = 1; x < m_iWitdh - 1; x++)
		{
			RandomCreateWall = rand() % 10;
			if(RandomCreateWall == 1)
			{
				if(WallMax < 3)
				{
					m_arrBlock.push_back(Block(x,y,BLOCK_WALL));
					WallMax++;
				}
			}
		}
	}
}

bool GameManager::CrushWall(int RandomX, int RandomY)
{
	for (list<Block>::iterator iter = m_arrBlock.begin(); iter != m_arrBlock.end(); iter++)
	{
		if (iter->Crush(RandomX, RandomY))
		{
			return true;
		}
	}
	return (m_cSneak.GetSneakX() == 0 ||
		m_cSneak.GetSneakY() == 0 ||
		m_cSneak.GetSneakX() == m_iWitdh - 1 ||
		m_cSneak.GetSneakY() == m_iHeight - 1);
}
bool GameManager::CrushFeed(int RandomX, int RandomY)
{
	for (list<Block>::iterator iter = m_arrFeed.begin(); iter != m_arrFeed.end(); iter++)
	{
		if (iter->Crush(RandomX, RandomY))
		{
			m_arrFeed.erase(iter);
			m_iFeed--;
			return true;
		}
	}
	return false;
}

void GameManager::CreateFeed()
{
	while (1)
	{
		int RandomX = rand() % (m_iWitdh - 2) + 1;
		int RandomY = rand() % (m_iHeight - 2) + 1;
		bool OverLap = false;

		if (CrushWall(RandomX, RandomY) == false)
		{
			if (CrushFeed(RandomX, RandomY) == false)
			{
				m_arrFeed.push_back(Block(RandomX, RandomY, BLOCK_FEED));
				m_iFeed++;
				break;
			}
		}
	}
}

void GameManager::Input()
{
	if(kbhit())
	{	
		char KeyCheck = getch();
		switch (KeyCheck)
		{
		case MOVEKEY_W:
			if (m_eKeyValue != KEYVALUE_DOWN)
			{
				m_eKeyValue = KEYVALUE_UP;
			}
			break;
		case MOVEKEY_S:
			if (m_eKeyValue != KEYVALUE_UP)
			{
				m_eKeyValue = KEYVALUE_DOWN;
			}
			break;
		case MOVEKEY_A:
			if (m_eKeyValue != KEYVALUE_RIGHT)
			{
				m_eKeyValue = KEYVALUE_LEFT;
			}
			break;
		case MOVEKEY_D:
			if (m_eKeyValue != KEYVALUE_LEFT)
			{
				m_eKeyValue = KEYVALUE_RIGHT;
			}
			break;
		default:
			break;
		}
	}
}

void GameManager::DrawMidPoint(string str, int x,int y)
{
	if (x > str.size() / 2)
		x -= str.size() / 2;
	gotoxy(x, y);
	cout << str;
}

bool GameManager::Menu()
{
	int iInput;
	DrawMidPoint("�� �� �� Snake Game �� �� ��", m_iWitdh, m_iHeight * 0.3);
	DrawMidPoint("1. ���� ����", m_iWitdh, m_iHeight * 0.4);
	DrawMidPoint("2. ���� ����", m_iWitdh, m_iHeight * 0.5);
	DrawMidPoint("���� : ", m_iWitdh, m_iHeight * 0.6);
	while(1)
	{
		cin >> iInput;
		switch (iInput)
		{
		case 1:
			return true;
		case 2:
			return false;
		default:
			break;
		}
	}
}

void GameManager::Play()
{

	int OldClock, CurClock, SneakSpeed;
	OldClock = clock();
	SneakSpeed = clock();
	Map();
	bool iRun = Menu();
	if (iRun == true)
	{
		system("cls");
		Map();
		CreateWall();
		m_cSneak.Init(m_iWitdh / 2, m_iHeight / 2);
	}
	while (iRun)
	{
		CurClock = clock();
		Input();
		if (CurClock - SneakSpeed >= 300)
		{
			if (CrushFeed(m_cSneak.GetSneakX(), m_cSneak.GetSneakY()) == true)
				m_cSneak.PlusEgg(m_eKeyValue);
			m_cSneak.Move(m_eKeyValue);
			if (CrushWall(m_cSneak.GetSneakX(), m_cSneak.GetSneakY()) == true)
				iRun = false;
			if (m_cSneak.CrushEgg() == true)
				iRun = false;
			SneakSpeed = CurClock;
		}
		if (CurClock - OldClock >= 1500)
		{
			if (m_iFeed < FeedMax)
				CreateFeed();
			OldClock = CurClock;
		}
	}
}

void GameManager::gotoxy(int x, int y)
{
	COORD Pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}

GameManager::~GameManager()
{
}