#pragma once
#include"Mecro.h"
#include"Block.h"
#include"Sneak.h"

enum MOVEKEY
{
	MOVEKEY_W = 'w',
	MOVEKEY_S = 's',
	MOVEKEY_A = 'a',
	MOVEKEY_D = 'd'
};

class GameManager
{
private:
	const int m_iWitdh;
	const int m_iHeight;
	KEYVALUE m_eKeyValue;
	int m_iFeed;
	//int m_iSneakX,m_iSneakY;
	Sneak m_cSneak;
	list<Block> m_arrBlock, m_arrFeed;
	const int FeedMax;

public:
	GameManager();
	~GameManager();

	void Play();

private:
	void Map();
	void CreateWall();
	void CreateFeed();
	bool Menu();
	bool CrushWall(int x,int y);
	bool CrushFeed(int x,int y);
	void Input();
	void gotoxy(int x, int y);
	void DrawMidPoint(string str,int x, int y);
};