#pragma once
#include<iostream>
#include<string>
#include<Windows.h>
#include<conio.h>
#include<iomanip>
#include<time.h>
#include<list>
using namespace std;


enum KEYVALUE
{
	KEYVALUE_NONE,
	KEYVALUE_UP,
	KEYVALUE_DOWN,
	KEYVALUE_LEFT,
	KEYVALUE_RIGHT
};