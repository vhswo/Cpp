#pragma once
#include"Mecro.h"
enum BLOCK
{
	BLOCK_START,
	BLOCK_WALL,
	BLOCK_FEED,
	BLOCK_BODY,
	BLOCK_END
};

class Block
{
private:
	int m_iBlockX;
	int m_iBlockY;
	BLOCK m_eBlcoktype;
	Block();

public:
	Block(int x, int y, BLOCK type);
	void Draw();
	int GetBlockX();
	int GetBlockY();
	bool Crush(int x, int y);
};

