#include "Sneak.h"

void Sneak::Init(int x,int y)
{
	m_iNowX = x;
	m_iNowY = y;
	DrawCharacter();
}
void Sneak::DrawCharacter()
{
	gotoxy(m_iNowX * 2, m_iNowY);
	cout << "��";
}
void Sneak::DeleteCharacter()
{
	gotoxy(m_iNowX * 2, m_iNowY);
	cout << "  ";
}

void Sneak::PlusEgg(KEYVALUE dir)
{
	Sneak tmp;
	tmp.m_iNowX = m_iNowX;
	tmp.m_iNowY = m_iNowY;
	if(!m_arrEgg.empty())
	{
		list<Sneak>::iterator iter = (--m_arrEgg.end());
		tmp.m_iNowX = iter->m_iNowX;
		tmp.m_iNowY = iter->m_iNowY;

	}
	m_arrEgg.push_back(tmp);
}

void Sneak::MoveEgg(int x,int y)
{
	if(!m_arrEgg.empty())
	{
		int k = x, z = y,l,i;
		for (list<Sneak>::iterator iter = m_arrEgg.begin(); iter != m_arrEgg.end(); iter++)
		{
			gotoxy(iter->m_iNowX*2, iter->m_iNowY);
			cout << "  ";
			l = iter->m_iNowX;
			i = iter->m_iNowY;
			iter->m_iNowX = k;
			iter->m_iNowY = z;
			k = l;
			z = i;
			gotoxy(iter->m_iNowX * 2, iter->m_iNowY);
			cout << "��";
		}
	}
	else
		DeleteCharacter();
	/*
	if(iter1 != m_arrEgg.end())
	{
		MoveEgg(iter1->m_iNowX, iter1->m_iNowY, iter1++); // �̰� �� �ȵǴ���
		iter1->m_iNowX = x;
		iter1->m_iNowY = y;
	}
	*/
}

void Sneak::Move(KEYVALUE dir)
{
	MoveEgg(m_iNowX, m_iNowY);
	switch (dir)
	{
	case KEYVALUE_UP:
		m_iNowY--;
		break;
	case KEYVALUE_DOWN:
		m_iNowY++;
		break;
	case KEYVALUE_LEFT:
		m_iNowX--;
		break;
	case KEYVALUE_RIGHT:
		m_iNowX++;
		break;
	}
	DrawCharacter();
}

bool Sneak::CrushEgg()
{
	for (list<Sneak>::iterator iter = m_arrEgg.begin(); iter != m_arrEgg.end(); iter++)
	{
		if (m_iNowX == iter->m_iNowX && m_iNowY == iter->m_iNowY)
			return true;
	}
	return false;
}

int Sneak::GetSneakX()
{
	return m_iNowX;
}
int Sneak::GetSneakY()
{
	return m_iNowY;
}

void Sneak::gotoxy(int x, int y)
{
	COORD Pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}