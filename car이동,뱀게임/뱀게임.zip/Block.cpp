#include "Block.h"
Block::Block(int x, int y, BLOCK type)
{
	m_iBlockX = x;
	m_iBlockY = y;
	m_eBlcoktype = type;
	Draw();
}
void Block::Draw()
{
	COORD Pos = { m_iBlockX*2, m_iBlockY };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);

	switch (m_eBlcoktype)
	{
	case BLOCK_WALL:
		cout << "��";
		break;
	case BLOCK_FEED:
		cout << "��";
		break;
	case BLOCK_BODY:
		cout << "��";
			break;
	}
}

int Block::GetBlockX()
{
	return m_iBlockX;
}

int Block::GetBlockY()
{

	return m_iBlockY;
}

bool Block::Crush(int x, int y)
{
	return (m_iBlockX == x && m_iBlockY == y);

}