#include "CreateCar.h"

CreateCar::CreateCar(){
	m_iNowX = STARTX;
	m_iMilySecond = clock();
	m_iSpeed = BAGICSPEED;
	m_iLevel = 0;
}

int CreateCar::GetNowX()
{
	if (m_iNowX >= END)
		DeleteCar();
	return m_iNowX;
}

CreateCar CreateCar::Move(int time,int SpeedLevel)
{
	CreateCar tmp;
	
	if (SpeedLevel == CHANGECHECK)
		m_iLevel++;

	if (m_iLevel == SPEEDUP)
	{
		m_iSpeed = BUSTER;
	}
	else
	{
		m_iSpeed = BAGICSPEED;
		m_iLevel = 0;
	}

	if (time - m_iMilySecond > m_iSpeed)
	{
		DeleteCar();		
		DrawCar();
		m_iMilySecond = time;
	}
	return tmp;
}

void CreateCar::DeleteCar()
{
	for (int y = 0; y < 3; y++)
	{
		gotoxy(m_iNowX-1, HEIGHT+y);
		for (int x = 0; x < 6; x++)
		{
			cout << "  ";
		}
	}
}

void CreateCar::DrawCar()
{
	for(int y = 0; y < CARHEIGHSIZE; y++)
	{
		gotoxy(m_iNowX, HEIGHT + y);
		if (y == 0)
		{
			for (int x = 0; x < CARWIDTHSIZE; x++)
			{
				if (x == 1)
					cout << "��";
				else if (x == 2 || x == 3)
					cout << "��";
				else if (x == 4)
					cout << "��";
				else
					cout << "  ";
			}
		}
		else if (y == 1)
		{
			for (int x = 0; x < CARWIDTHSIZE; x++)
			{
				if (x == 0)
					cout << "��";
				else if (x == 1)
					cout << "��";
				else if (x == 4)
					cout << "��";
				else if (x == 5)
					cout << "��";
				else 
					cout << "��";
			}
		}
		else
		{

			for (int x = 0; x < CARWIDTHSIZE; x++)
			{
				if (x == 0)
					cout << "��";
				else if (x == 1 || x == 4)
					cout << "��";
				else if (x == 5)
					cout << "��";
				else
					cout << "��";
			}
		}
		cout << endl;
	}
	m_iNowX++;
}

void CreateCar::gotoxy(int x, int y)
{
	COORD Pos = { x,y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}
CreateCar::~CreateCar() {}