#pragma once
#include"Mecro.h"
class CreateCar
{
//�� �׸���, �ð��� �̵�
private:
	int m_iNowX;
	int m_iMilySecond;
	int m_iSpeed;
	int m_iLevel;
public:
	int GetNowX();
	void DrawCar();
	void DeleteCar();
	CreateCar Move(int time,int level);
	void gotoxy(int x, int y);
	CreateCar();
	~CreateCar();
};

