#pragma once
#include<iostream>
#include<string>
#include<Windows.h>
#include<conio.h>
#include<iomanip>
#include<time.h>
#include<list>
#define BAGICSPEED 200
#define BUSTER 50
#define SPEEDBUTTEN 32
#define END 90
#define HEIGHT 5
#define STARTX 5
#define SPEEDUP 1
#define CREATECAREVERYSECOND 5000
#define CHANGECHECK 1
#define CARWIDTHSIZE 6
#define CARHEIGHSIZE 3
using namespace std;