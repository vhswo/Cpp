#pragma once
#include"CreateCar.h"
class TimeMap
{
private:
	list<CreateCar> m_arrCreateCar;
public:
	void Time();
	TimeMap();
	~TimeMap();

};

