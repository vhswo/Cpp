#include "TimeMap.h"

TimeMap::TimeMap(){}

void TimeMap::Time()
{
	int FiveSecond,CurClock;
	int level = 0;
	FiveSecond = clock();
	list<CreateCar>::iterator Car;
	CreateCar cCartmp;
	m_arrCreateCar.push_back(cCartmp.Move(0, level));
	while (1)
	{
		char sp;
		CurClock = clock();

		if (CurClock - FiveSecond > CREATECAREVERYSECOND)
		{
			m_arrCreateCar.push_back(cCartmp.Move(0, level));
			FiveSecond = CurClock;
		}

		if (kbhit())
		{
			sp = getch();
			if (sp == SPEEDBUTTEN)
			{
				level++;
			}
		}

		for (Car = m_arrCreateCar.begin(); Car != m_arrCreateCar.end();)
		{
			Car->Move(CurClock,level);
			if (Car->GetNowX() == END)
				m_arrCreateCar.erase(Car++);
			else
				Car++;
		}

		level = 0;
	}
}
TimeMap::~TimeMap() {}