#include"TimeMap.h"

void main()
{
	TimeMap TM;
	TM.Time();
	
}