#include"ProblemManager.h"

void main()
{
	ProblemManager cPM;
	cPM.Title();
}