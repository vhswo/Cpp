#include "Problem.h"
void Problem::Work(int iDay,int iMoney, int iTime)
{
	cout << "�ð� : " << iTime << "�ð�\t �� �� : " << iDay << endl;
	cout << "�޷� : " << (iTime * iMoney) * iDay;
	system("pause");
}

void Problem::SumFromOne(int iLastNum)
{
	int iSum = 0;
	for (int i = 1; i <= iLastNum; i++)
		iSum += i;
	cout << "1 ~ " << iLastNum << " �� �� : " << iSum;
	system("pause");
}

void Problem::GuGuDan(int iLeastNum, int iLastNum)
{
	for (int i = 0; i <= 9; i++)
	{
		for (int j = iLeastNum; j <= iLastNum; j++)
		{
			if (i == 0)
				cout << "====" << j << " ��====\t";
			else
				cout << j << " x " << i << " = " << j * i << "\t";
		}
		cout << endl;
	}

	system("pause");
}