#pragma once
#include<iostream>

using namespace std;



class Problem
{
private:
public:
	void Work(int iDay,int iMoney = 7500, int iTime = 8);
	void SumFromOne(int iLastNum = 10);
	void GuGuDan(int iLeastNum = 2, int iLastNum = 9);
};

