#pragma once
#include"Problem.h"
#include<Windows.h>
enum TITLE
{
	TITLE_PROBLEM_START,
	TITLE_PROBLEM_WORK,
	TITLE_PROBLEM_SUMFROMONE,
	TITLE_PROBLEM_GUGUDAN,
	TITLE_PROBLEM_EXIT
};
enum YESORNO
{
	YESORNO_YES = 1,
	YESORNO_NO
};

class ProblemManager
{
private:
	Problem cP;
	int m_iDay, m_iTime, m_iMoney;
	int m_iLeastNum, m_iLastNum;
	bool bCheck;
	int m_iSelect;
public:
	void Title();
	void TitleWork();
	void TitleSumfromOne();
	void TitleGugudan();
};

