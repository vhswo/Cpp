#include "OverloadingQuize.h"

void OverloadingQuize::SetQuizeOne(int Num1, int Num2)
{
	int Sum = 1;
	for (int i = 1; i <= Num2; i++)
		Sum *= Num1;
	cout << Num1 << "�� " << Num2 << "�� : " << Sum << endl;
}
void OverloadingQuize::SetQuizeOne(char ch, int Num2)
{
	char cLast = ch;
	for (int i = 1; i <= Num2; i++)
	{
		if (cLast >= 'z')
			cLast = 'a';
		else
			cLast++;
	}
	cout << ch << " >> " << Num2 << " : " << cLast << endl;
}
void OverloadingQuize::SetQuizeTwo(string strStr)
{
	cout << strStr << " -> ";
	for (int i = 0, j = strStr.size() - 1; i < strStr.size() || j >= 0; i++, j--)
	{
		char chTmp;
		if (i < j)
		{
			chTmp = strStr[i];
			strStr[i] = strStr[j];
			strStr[j] = chTmp;
		}
		else
			break;
	}
	cout << strStr << endl;
}
void OverloadingQuize::SetQuizeTwo(string strStr1, string strStr2)
{
	string strSum;
	cout << strStr1 << " + " << strStr2 << " = ";
	strSum = strStr1 + strStr2;
	cout << strSum << endl;
}
void OverloadingQuize::SetQuizeThree(int arrNum[5])
{
	int iTmp;
	cout << "==========iarr==========" << endl;
	for (int i = 0; i < 5; i++)
	{
		for (int j = i + 1; j < 5; j++)
		{
			if (arrNum[i] < arrNum[j])
			{
				iTmp = arrNum[i];
				arrNum[i] = arrNum[j];
				arrNum[j] = iTmp;
			}
		}
		cout << "iarr[" << i << "] : " << arrNum[i] << endl;
	}
}
void OverloadingQuize::SetQuizeThree(char arrCh[5])
{
	int iTmp;
	cout << "==========charr==========" << endl;
	for (int i = 0; i < 5; i++)
	{
		for (int j = i + 1; j < 5; j++)
		{
			if (arrCh[i] > arrCh[j])
			{
				iTmp = arrCh[i];
				arrCh[i] = arrCh[j];
				arrCh[j] = iTmp;
			}
		}
		cout << "iarr[" << i << "] : " << arrCh[i] << endl;
	}
}