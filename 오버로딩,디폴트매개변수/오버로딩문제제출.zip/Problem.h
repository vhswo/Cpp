#pragma once
#include<iostream>

using namespace std;

enum YESORNO
{
	YESORNO_YES = 1,
	YESORNO_NO
};

class Problem
{
private:
	int m_iDay, m_iTime, m_iMoney;
	int m_iLeastNum,m_iLastNum, m_iSum;
	int m_iSelect;
public:
	void Work(int iMoney = 7500, int iTime = 8);
	void SumFromOne(int iLastNum = 10);
	void GuGuDan(int iLeastNum = 2, int iLastNum = 9);
};

