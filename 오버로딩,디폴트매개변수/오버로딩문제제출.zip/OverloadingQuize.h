#pragma once
#include<iostream>
using namespace std;
class OverloadingQuize
{
private:
public:
	void SetQuizeOne(int Num1, int Num2);
	void SetQuizeOne(char ch, int Num2);
	void SetQuizeTwo(string strStr);
	void SetQuizeTwo(string strStr1, string strStr2);
	void SetQuizeThree(int arrNum[5]);
	void SetQuizeThree(char arrCh[5]);
};

