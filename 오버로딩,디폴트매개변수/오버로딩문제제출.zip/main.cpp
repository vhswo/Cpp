#pragma once
#include"QuizeManager.h"

void main()
{
	QuizeManager QM;
	QM.ShowQuizeOne();
	QM.ShowQuizeTwo();
	QM.ShowQuizeThree();
}