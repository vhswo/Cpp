#pragma once
#include"OverloadingQuize.h"
#include<string>
class QuizeManager
{
private:
	int m_iNum1, m_iNum2;
	int m_iarrNum[5];
	char m_carrCh[5];
	char m_cCh;
	bool m_bCheck;
	string m_strStr1, m_strStr2;
	OverloadingQuize OQ;
public:
	bool LeastNumCheck();
	void ShowQuizeOne();
	void ShowQuizeTwo();
	void ShowQuizeThree();
	bool AlpabetCheck();
};

